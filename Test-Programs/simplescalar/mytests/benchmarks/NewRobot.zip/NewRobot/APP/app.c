/***************************************************************************/
/* Using Ballybot 2                                                        */
/* Balancing robot algorithm with PID control for driving straight         */
/* Author: Rich Chi Ooi                                                    */
/* Version: 1.3                                                            */
/* Date:14.08.2003                                                         */ 
/***************************************************************************/

#include <includes.h>

//// Application-specific declarations ///
/*metre per tick*/
static const float MPT = (M_PI*0.051)/3495;

/*Gyro Scaling to rad/s */
static const float GY_SCALE = 0.002798;

/*Time step for encoder reading*/
static const float DT = 0.02;

MotorHandle motorLeft;
MotorHandle motorRight;
QuadHandle quadLeft;
QuadHandle quadRight;

/*Gain values for state control*/
static  float X_K = -31.6;
static const float Xdot_K = -34.3;
static const float PHI_K = 1467.6;
static const float PHIdot_K = 113.8;

/*PID Gains*/
static const float KP = 0.35;
static const float KI = 0.025;
static const float KD = 0.75;

/* Global variables*/
static float distance_old = 0;
static int r_old = 0;
static int e_old = 0;
static int e_old2 = 0;
int turnL =0;
int turnR =0;
float move = 0;

ServoHandle gyro; //cleekee: needed?

image img1, img2, img3, img4;
image *ip1, *ip2, *ip3, *ip4;
int angle2, speed;
int mymaxrow=IMAGE_ROWS, mymaxcol=IMAGE_COLUMNS;
int half=IMAGE_COLUMNS/2, third=IMAGE_COLUMNS/3;

OS_MEM *img_mem;
BYTE CommBuf[4][IMAGE_FRAME_SIZE];

void stateInit();
void balance();
void navigation();
void reporting();
void remote();

unsigned int exec_time_addr = 0x40050000, exec_time_addr_max = 0x40050140;
unsigned int time_start, time_end, exec_time, max_exec_time;

//// OS-specific declarations ///
static  OS_STK  AppTaskStartStk[APP_TASK_START_STK_SIZE];
static  OS_STK  AppTaskBalanceStk[APP_TASK_BALANCE_STK_SIZE];
static  OS_STK  AppTaskNavigationStk[APP_TASK_NAVIGATION_STK_SIZE];
static  OS_STK  AppTaskReportingStk[APP_TASK_START_STK_SIZE];
static  OS_STK  AppTaskRemoteStk[APP_TASK_REMOTE_STK_SIZE];

static void AppTaskStart(void *p_arg);
void UserTaskCreate(void);

static void Task_Balance(void *pdata);
static void Task_Navigation(void *pdata);
static void Task_Reporting(void *pdata);
static void Task_Remote(void *pdata);

int steer(int, int, int, int, int, int, int);

/// Semaphore Define  ///
OS_EVENT *sem_track_obj; //signal to navigate to a new object
OS_EVENT *sem_remote_cmd; //signal to execute a remote command

int main (void)
{
    INT8U err;

    BSP_IntDisAll();                                                    /* Disable ALL interrupts to the interrupt controller       */

    OSInit();                                                           /* Initialize uC/OS-II                                      */    

    //setup semaphores
    sem_track_obj = OSSemCreate(0);
    sem_remote_cmd = OSSemCreate(0);

    img_mem = OSMemCreate(&CommBuf[0][0], 4, IMAGE_FRAME_SIZE, &err);

    time_start=0;
    time_end=0;
    exec_time=0;
    max_exec_time=0;
                                                                        
    OSTaskCreateExt(AppTaskStart,                                       /* Create start task                                        */
                    NULL,
                    (OS_STK *)&AppTaskStartStk[APP_TASK_START_STK_SIZE - 1],
                    APP_TASK_START_PRIO,
                    APP_TASK_START_PRIO,
                    (OS_STK *)&AppTaskStartStk[0],
                    APP_TASK_START_STK_SIZE,
                    NULL,
                    OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);

    OSStart();                                                          /* Start uC/OS-II                                           */

    return 0;
}

static void AppTaskStart (void *p_arg)
{
    (void)p_arg;                                                        /* Prevent compiler warning                                 */

    BSP_Init();                                                         /* Initialize the BSP                                       */ 

    /*initialize ports and sensors*/   
    gyroInit(gyro);
    inclinoInit();
    motorLeft = MOTORInit(MOTOR_LEFT);
    motorRight = MOTORInit(MOTOR_RIGHT);
    quadLeft = QUADInit(QUAD_LEFT);
    quadRight = QUADInit(QUAD_RIGHT);

    QUADReset(quadRight);
    QUADReset(quadLeft);
   
    stateInit(); 

#if 1
    /* Integer divider to reduce CPU frequency */
    printf("HW_CLKCTRL_CPU = %x\n", readl(0x80040050));
    //writel(0x0001000b, 0x80040050);
    printf("New HW_CLKCTRL_CPU = %x\n", readl(0x80040050));
#else
    /* Fractional clock divider to reduce CPU frequency up to factor of 2 only.
     * more fine-grained than integer divider */
    printf("HW_CLKCTRL_FRAC0 = %x\n", readl(0x800401b0));
    //*((u8 *)(0x800401b0)) = 35;
    printf("New HW_CLKCTRL_FRAC0 = %x\n", readl(0x800401b0));
#endif

    /* Estimate CPU frequency */
    volatile unsigned int start_hclk_count, hclk_count;
    start_hclk_count = HW_DIGCTL_HCLKCOUNT_RD();
    OSTimeDlyHMSM(0,0,1,0);
    hclk_count = HW_DIGCTL_HCLKCOUNT_RD() - start_hclk_count;
    printf("Estimated CPU frequency = %u Hz\n", hclk_count*3);

    //initialize user tasks
    UserTaskCreate();

    //Delete itself
    OSTaskDel(OS_PRIO_SELF);    
}

void UserTaskCreate(void)
{
#if 1
    OSTaskCreateExt(Task_Balance,
                    NULL,
                    (OS_STK *)&AppTaskBalanceStk[APP_TASK_START_STK_SIZE - 1],
                    OS_USER_TASK1_PRIO,
                    OS_USER_TASK1_PRIO,
                    (OS_STK *)&AppTaskBalanceStk[0],
                    APP_TASK_START_STK_SIZE,
                    NULL,
                    OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);
#endif
#if 1
    OSTaskCreateExt(Task_Navigation,
                    NULL,
                    (OS_STK *)&AppTaskNavigationStk[APP_TASK_NAVIGATION_STK_SIZE - 1],
                    OS_USER_TASK3_PRIO,
                    OS_USER_TASK3_PRIO,
                    (OS_STK *)&AppTaskNavigationStk[0],
                    APP_TASK_NAVIGATION_STK_SIZE,
                    NULL,
                    OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);
#endif
#if 0
    OSTaskCreateExt(Task_Reporting,
                    NULL,
                    (OS_STK *)&AppTaskNavigationStk[APP_TASK_START_STK_SIZE - 1],
                    OS_USER_TASK4_PRIO,
                    OS_USER_TASK4_PRIO,
                    (OS_STK *)&AppTaskReportingStk[0],
                    APP_TASK_START_STK_SIZE,
                    NULL,
                    OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);
#endif
#if 1
    OSTaskCreateExt(Task_Remote,
                    NULL,
                    (OS_STK *)&AppTaskRemoteStk[APP_TASK_START_STK_SIZE - 1],
                    OS_USER_TASK2_PRIO,
                    OS_USER_TASK2_PRIO,
                    (OS_STK *)&AppTaskRemoteStk[0],
                    APP_TASK_START_STK_SIZE,
                    NULL,
                    OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);
#endif
}

static void Task_Balance(void *pdata)
{
    INT32U tick_period = (unsigned)(0.020*OS_TICKS_PER_SEC); //50Hz

    printf("\nBalance task initialized!");
    
    while(1) {        
#if (TASK_TO_MEASURE == 1)
        printf("\nmax_exec_time=%u", max_exec_time);
        START_MEASURE();
#endif
        balance(tick_period);
    } 
}

static void Task_Navigation(void *pdata)
{
    INT32U tick_period = (unsigned)(0.05*OS_TICKS_PER_SEC); //20Hz

    printf("\nNavigation task initialized!");

    while (1) {   
#if (TASK_TO_MEASURE == 3)
        printf("\nmax_exec_time=%u", max_exec_time);
        START_MEASURE();
#endif     
        printf("\nmax_exec_time=%u", max_exec_time);
        navigation(tick_period);
    }    
}

#if 0
static void Task_Reporting(void *pdata)
{
    INT32U tick_period = (unsigned)(0.05*OS_TICKS_PER_SEC); //20Hz

    printf("\nReporting task initialized!");

    while (1) {                   	
        reporting(tick_period);
    }
}
#endif

static void Task_Remote(void *pdata)
{
    printf("\nRemote task initialized!");

    while (1) {       
#if (TASK_TO_MEASURE == 2)
        printf("\nmax_exec_time=%u", max_exec_time);
        START_MEASURE();
#endif                 	
        remote();
    }
}

/*
 *Initialize the filter
 */
void stateInit(){

  int gyRaw = 0;
  
  gyRaw = gyroRaw();
  q_bias =gyRaw*GY_SCALE;
  angle = incAngle(); 
}

void balance(int tick_period){  
    INT32U start_tick, end_tick, tick_diff;
    int i;
    float gy_angle, in_angle;
    int enc_left, enc_right, e_func;
    float X, Xdot;
    float PHI, PHIdot;
    int r_motor;
    int motor_command;

    start_tick = OSTimeGet();

    gy_angle = gyroRaw()*GY_SCALE;
    in_angle = incAngle();

    stateUpdate(gy_angle);
    kalmanUpdate(in_angle);

    enc_left = QUADRead(quadLeft);
    enc_right = QUADRead(quadRight);
    
    //printf("\nenc_left_new=%d, enc_right_new=%d", enc_left_new, enc_right_new);

    PHI = in_angle;
    PHIdot = rate;

    /* cleekee: add additional load to task by putting a loop */
    /*for (i=0; i<8000; i++) {
        ;
    }*/

    X = ((enc_left+enc_right)/2)*MPT;
    Xdot = ((X - distance_old)/DT)+move;

    //printf("\nM_PI=%d, MPT=%d", (int)M_PI, (int)(MPT*1000000));
    //printf("\nX=%d, Xdot=%d", (int)(X*1000000), (int)(Xdot*1000000));
    //printf("\nX=%d.%d", X, ((float)((int)X)-X)*1000);
    //printf("\nX=%f, Xdot=%f", X, Xdot);

    e_func = enc_left-enc_right;
    r_motor =(int)( r_old+KP*(e_func-e_old)+KI*(e_func+e_old)/2
          +KD*(e_func-2*e_old+e_old2));
    e_old2 = e_old;
    e_old = e_func;
    r_old = r_motor;
    distance_old = X;

    motor_command =(int) (-1*((X*X_K)+(Xdot*Xdot_K)+(PHI*PHI_K)+(PHIdot*PHIdot_K)));

    if(motor_command>95){
        motor_command = 95;
    }
    if(motor_command<-95){
        motor_command = -95;
    }

    printf("\nMOTORLEFT=%d+%d", motor_command, turnL);
    printf("\nMOTORRIGHT=%d+%d", motor_command, turnR);

    MOTORDrive(motorLeft,(motor_command+turnL));
    D2(printf("\nMOTORLEFT=%d", motor_command+turnL));
    MOTORDrive(motorRight,(motor_command+turnR));
    D2(printf("\nMOTORRIGHT=%d", motor_command+turnR));

    end_tick = OSTimeGet();
    tick_diff = end_tick - start_tick;
    D(printf("\nBalancing... diff=%i, period=%i", tick_diff, tick_period));

    if (tick_diff < tick_period)
        OSTimeDly(tick_period - tick_diff);
}

/* ********************************************************************* */
/*                                                                       */
/* This routine                                                          */
/* executes the algorithm that gets the image data, processes it with    */
/* edge-detection and thresholding functions,                            */
/* computes lowest and highest edges, and computes the new steering      */
/* angle and speed.                                                      */
/*                                                                       */
/* ********************************************************************* */
void navigation(INT32U tick_period) {
    INT32U start_tick, end_tick, tick_diff;
    INT8U err;
	BYTE blk = 0;
	Boolean blank, stop;
	int row, col;
	int xL, yL, xC, yC, xR, yR;

    start_tick = OSTimeGet();

	//ip1=&img1;ip2=&img2;ip3=&img3;ip4=&img4;
    ip3=&img3;ip4=&img4;
	
    ip1 = OSMemGet(img_mem, &err);
    ip2 = OSMemGet(img_mem, &err);

	angle2 = 0;
	speed = 0;

    /* Get image */
	CAMGetFrame(ip1);

	/* Do edge detection */
	IPSobel(ip1, ip2);
	
	/* Thresholding */ 
	//IPL_threshold((BYTE *)ip2, (BYTE *)ip3, th);

    OSMemPut(img_mem, (void *)ip1);                           
	
	/* Find Left lowest point */
	yL = 1;
	xL = 1;
	row = mymaxrow - 1;
	stop = FALSE;
	
	for (col=2; col<third; col++) {
		while (row > 1 && stop == FALSE) {
			if ( img3[row][col] == blk) {/* pixel black? */
				if (row >= yL) {
					stop = TRUE;
					yL = row;
					xL = col;
				}
			}
			row -= 1;
		}
		stop = FALSE;           /* Reset stop flag */
		row = mymaxrow - 1; 
	}                                                      

	/* Display the left marker */
	//marker(yL, xL);

	/* Find Center Highest point */
	yC = mymaxrow - 1;              /* Init y to bottom */
	xC = half;                      /* Init x to center */
	row = mymaxrow - 1;
	blank = TRUE;                   /* Init blank region flag */
	stop = FALSE;                   /* Init stop flag */
	for (col=third+1; col<third*2; col++) {
		while (row > 1 && stop == FALSE) {
			if ( img3[row][col] == blk) {/*pixel black?*/
				blank = FALSE;    /* Not blank */ 
				stop = TRUE;      /* Highest in row*/
				if (row < yC) {   /*Highest overall?*/
					yC = row;
					xC = col;
				}
			}
			row -= 1;
		}
		if (row == 1) {         /* All the way w/o edge? */
			yC = 1;         /* This is highest */
			xC = col;
		}
		row = mymaxrow - 1;             /* Reset to bottom */
		stop = FALSE;                   /* Reset stop flag */
	}                                                      
	
	/* No edges in this Center region? */
	if (blank == TRUE) {                /* Set to Mid-region */
		yC = 1;
		xC = half;
	}
	   
	/* Display the center marker */
	//marker(yC, xC);

	/* Find Right lowest point */
	yR = 1;
	xR = mymaxcol-4;
	row = mymaxrow - 1;
	stop = FALSE;
	for (col= mymaxcol-4; col>third*2; col--) {
		while (row > 1 && stop == FALSE) {
			if (img3[row][col] == blk) {/* pixel black? */
				if (row >= yR) {
					stop = TRUE;
					yR = row;
					xR = col;
				}
			}
			row -= 1;
		}
		stop = FALSE;
		row = mymaxrow - 1;
	}

	/* Display the right marker */
	//marker(yR, xR);
		 
	/* Compute new Angle and Speed */
	steer(0, xL, yL, xC, yC, xR, yR);

    OSMemPut(img_mem, (void *)ip2);

    end_tick = OSTimeGet();
    tick_diff = end_tick - start_tick;
    D(printf("\nNavigating... end_tick=%i, start_tick=%i", end_tick, start_tick));
    D(printf("\nNavigating... diff=%i, period=%i", tick_diff, tick_period)); 

    if (tick_diff < tick_period)
        OSTimeDly(tick_period - tick_diff);
}

#if 0
void reporting(INT32U tick_period) {
    INT32U start_tick, end_tick, tick_diff;

    start_tick = OSTimeGet();

    //DOWNLINK_SEND_KALMAN(&PHI, &PHIdot, &X, &Xdot);
    DOWNLINK_SEND_IMAGE(ip1);

    end_tick = OSTimeGet();
    tick_diff = end_tick - start_tick;
    D(printf("\nReporting... diff=%i, period=%i", tick_diff, tick_period)); 

    if (tick_diff < tick_period)
        OSTimeDly(tick_period - tick_diff);
}
#endif

void remote() {
    Int16U code;
    INT8U return_code = OS_NO_ERR;
    int i;
//END_MEASURE();
    //wait for user to input a command
    OSSemPend(sem_remote_cmd, 0, &return_code);

    printf("\nRECEIVED IR COMMAND: ");
    D(printf("\nRECEIVED IR COMMAND: "));    

    /* add additional load to task by putting a loop */
    /*for (i=0; i<800; i++) {
        ;
    }*/

    switch (code = IRTVRead()) {             	  	
    case RC_2: // Move forward
        D(printf("2\n"));
        X_K = 0;
        turnL = 0;
        turnR = 0;
        move = 0.15;            
        break;		                  
    case RC_4: // Turn left
        D(printf("4\n"));
        X_K = 0;
        turnL = -5;
        turnR = 5; 
        break;                  		
    case RC_5: // Turn on vision tracking navigation
        D(printf("5\n"));
        X_K = -31.6;
        QUADReset(quadRight);
        QUADReset(quadLeft);
        move = 0;
        turnL = 0;
        turnR = 0;
        //OSSemPost(sem_track_obj);  
        OSTaskResume(OS_USER_TASK3_PRIO);
        break;                  		
    case RC_6: // Turn right
        D(printf("6\n"));
        X_K = 0;
        turnL = 5;
        turnR = -5;
        break;     
    case RC_8: // Move backward
        D(printf("8\n"));
        X_K = 0;
        move = -0.15; 
        break;             
    case RC_STANDBY:
        D(printf("Stop navigation\n"));
        OSTaskSuspend(OS_USER_TASK3_PRIO);//OSTaskDel(OS_USER_TASK3_PRIO);
        move = 0;
        turnL = 0;
        turnR = 0;
        break;
    default:
        break;			
    }	
//END_MEASURE();
}

int steer(int md, int xlt, int ylt, int xcn, int ycn, int xrt, int yrt)
/* ********************************************************************* */
/*                                                                       */
/* This routine computes the new steering angle and speed, based on the  */
/* execution mode (Realtime or Slow) and the (x,y) values of the sector  */
/* markers.                                                              */
/*                                                                       */
/* ********************************************************************* */

{
	int new_angle;
	int border_rt, border_lt;
	int band = 5;
	float const1 = 0.025;
	float const2 = 0.75;
	float const3 = 0.25;

	/* Adjust Y values to reflect origin at base of LCD */
	ylt = mymaxrow - ylt;             
	ycn = mymaxrow - ycn;             
	yrt = mymaxrow - yrt;

	/* Adjust X values to reflect origin at center of LCD */
	xlt = xlt - half;
	xcn = xcn - half;
	xrt = xrt - half;

	/* Compute adjusted x-value for sector boundaries */
	border_lt = third - half;
	border_rt = 2 * third - half;
	
	/* Compute the new speed */
	speed = (const2 * speed) + (const3 * (ycn - 5));

	if (speed < 5)                  /* obstacle immediately ahead? */
		speed = 0;              

	/* If path blocked, execute right-angle turn */
	if (speed==0) 
		angle2 = 90;
	
	/* Otherwise, compute current image angle and new steering angle */
	else { 
		/* Is there a blank left or right sector condition? */
		if ((xlt <= -half && ylt >= mymaxrow)
					|| (xrt >= half && yrt >= mymaxrow))
			new_angle = xcn;
		else {
			/* Is there either diagonal condition? */
			if (ylt >= mymaxrow-band && yrt <= band)
		
				new_angle = xcn;
			 
			else {
				if (ylt <= band && yrt >= mymaxrow-band)
					new_angle = xcn;
				
				else
					/* Normal condition */
					new_angle = xcn 
					   + const1 * (yrt-ylt) * (xrt-xlt);

			}
		}
	
		/* Compute the new steering angle */
		angle2 = (const2 * angle2) + (const3 * new_angle);


		/* Computed angle out of legal range? */
		if (angle2 > 90) 
			angle2 = 90;
		
		if (angle2 < -90)      
			angle2 = -90;

	}

    /* cleekee: convert angle,speed to move,turnL,turnR */
    move = 0.15*speed;
    turnL = angle2/18;
    turnR = -turnL;

	return(0);
}

void start_measure_wcet() {
    /*__disable_irq();
    ICOLL_DisableIntr(INT_TIMER2); //disable gyro
    ICOLL_DisableIntr(INT_TIMER3); //disable inclino
    ICOLL_DisableIntr(INT_TIMER0); //disable tick ISR*/

    time_start=getCurrent24MHzCount();
}

void write_wcet() {
    time_end=getCurrent24MHzCount();

    exec_time = time_end-time_start;
    if (time_end>time_start && exec_time > max_exec_time) {
        max_exec_time = exec_time;
    }

    if (exec_time_addr<exec_time_addr_max && time_end>time_start && time_end-time_start > 0x3349f) {
        writel(time_end-time_start, exec_time_addr); 
        exec_time_addr+=4;
        time_start=0xffffffff;
    }

    /*ICOLL_EnableIntr(INT_TIMER2); //enable gyro
    ICOLL_EnableIntr(INT_TIMER3); //enable inclino
    ICOLL_EnableIntr(INT_TIMER0); //enable tick ISR*/
}
