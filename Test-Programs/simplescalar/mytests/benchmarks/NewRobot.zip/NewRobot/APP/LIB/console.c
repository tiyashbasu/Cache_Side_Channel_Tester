#include <includes.h>

int printf(const char *fmt, ...)
{
	va_list args;
	INT32U i;
	char printbuffer[256];

	va_start(args, fmt);

	/* For this to work, printbuffer must be larger than
	 * anything we ever want to print.
	 */
	i = vsprintf(printbuffer, fmt, args);
	va_end(args);

	/* Print the string */
	serial_puts(printbuffer);

	return 0;
}
