#ifndef _CONSOLE_H_
#define _CONSOLE_H_

int printf(const char *fmt, ...);

#endif

