#ifndef _VSPRINTF_H_
#define _VSPRINTF_H_

unsigned long simple_strtoul(const char *cp, char **endp, unsigned int base);
long simple_strtol(const char *cp, char **endp, unsigned int base);

#ifdef CFG_64BIT_STRTOUL
unsigned long long simple_strtoull (const char *cp, char **endp, unsigned int base);
#endif

int sprintf(char * buf, const char *fmt, ...);
int vsprintf(char *buf, const char *fmt, va_list args);

#endif

