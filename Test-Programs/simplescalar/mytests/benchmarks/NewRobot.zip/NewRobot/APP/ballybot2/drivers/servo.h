#ifndef  SERVO_H
#define  SERVO_H

#include <includes.h>

/*Initialize given servo*/
int SERVOInit(); // We have only one servo in our application
/*Set the given servos to the same given angle*/
int SERVOSet (ServoHandle dev, int angle);
/*Release given servos*/
int SERVORelease(ServoHandle dev);

#endif
