#include <includes.h>

Int16U irtv_masks[ IRTV_NB_PULSES ];

extern OS_EVENT *sem_remote_cmd; //signal to execute a remote command



/*Initialize GPIO input (GPIO_0_19 Pin34 APF28Dev Kit) for capturing IRTV signal*/
void IRTV_Init( void ) {
   // Set HW_PINCTRL_MUXSELx (set bit 6 and 7)
   writel(0x000000C0, HW_PINCTRL_MUXSEL1_SET);
   // Enable input
   writel(IRTV_MASK, HW_PINCTRL_DOE0_CLR);
   // Set the HW_PINCTRL_PULLx (enable pull up resister)
   writel(IRTV_MASK, HW_PINCTRL_PULL0_SET);
   // Edge detection
   writel(IRTV_MASK, HW_PINCTRL_IRQLEVEL0_CLR);   
   // falling edge detection
   writel(IRTV_MASK, HW_PINCTRL_IRQPOL0_CLR);
   // Clear interrupt
   writel(IRTV_MASK, HW_PINCTRL_IRQSTAT0_CLR);
   // Enable as interrupt pin
   writel(IRTV_MASK, HW_PINCTRL_PIN2IRQ0_SET);
   // Enable the interrupt signal back to Interrupt Collector
   writel(IRTV_MASK, HW_PINCTRL_IRQEN0_SET);  
   
   /*Setup IRTV interrupt*/
   ICOLL_SetupIntr(IRTV_Interrupt_Handler, 0, INT_PINCTRL0, LEVEL3);
   /*Enable Interrupt in ICOLL*/
   ICOLL_EnableIntr(INT_PINCTRL0);

   D(printf("\nInitialize IRTV successfully")); 
}

#define RestartIRTVCycle() { state = 0;  sync_start = T10kHz_count; return; }

void  IRTV_Interrupt_Handler (void)
{
  static Int32U	last;
  Int32U	this;
  Int32U	width;
  static Int8U	state;
  static Int8U	sync_start;    

  printf("\nir");

#if (TASK_TO_MEASURE == 5)
	START_MEASURE();
#endif

  this		= T10kHz_count;  
  width		= (this - last)*10; //Normalized with 10kHz counter 
  last		= this;
  
  if( state == 0 ) {
    Int32U end = T10kHz_count;
    Int32U diff = (end - sync_start);
    sync_start = end;    
    if( diff > 700 ) { //sync signal > 7ms      
      //Change to data receiving state
      state = 1;
    }
  } 
  else {    
    if((width <800)||(width>1700))
	RestartIRTVCycle();  
    if((width >= 800)&&(width <= 1200)){
      irtv_masks[state - 1] = 0; //receive bit 0             
    }else if((width >= 1300)&&(width <= 1700)){
      irtv_masks[state - 1] = 1; //receive bit 1            
    }

    if (state >= IRTV_NB_PULSES) {      
      //Post semaphore to waiting task
      OSSemPost(sem_remote_cmd); 
//START_MEASURE();
      //Restart new IRTV Cycle
      LED_TOGGLE();
      RestartIRTVCycle();      
    } else {
      state++;
    }
  }  
  // Clear interrupt flag
  writel(IRTV_MASK, HW_PINCTRL_IRQSTAT0_CLR); 

#if (TASK_TO_MEASURE == 5)
	END_MEASURE();
#endif
}

Int16U IRTVRead (void){ 
Int8S 	index;
Int16U keyCode;
//Calculate key code
keyCode=0;
for(index=15;index>=0;index--) {  
  if(irtv_masks[index]==1){
    keyCode = keyCode | 0x0001;
  }
  if(index>0) keyCode=keyCode << 1;
}

return keyCode;
}
