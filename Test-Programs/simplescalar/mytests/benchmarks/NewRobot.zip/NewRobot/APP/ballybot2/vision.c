#include <includes.h>

int abs(int n) {
    const int ret[2] = {n, -n};
    return ret[n<0];
}

/* Sobel operator algorithm thanks to:
 * http://www.pages.drexel.edu/~weg22/edge.html */
void IPSobel(image *ip1, image *ip2)
{   
   unsigned int		X, Y;
   int			I, J;
   long			sumX, sumY;
   int			SUM;
   int			GX[3][3];
   int			GY[3][3];
   BYTE*       outputImg;

   outputImg = (BYTE *) ip2;

   /* 3x3 GX Sobel mask.  Ref: www.cee.hw.ac.uk/hipr/html/sobel.html */
   GX[0][0] = -1; GX[0][1] = 0; GX[0][2] = 1;
   GX[1][0] = -2; GX[1][1] = 0; GX[1][2] = 2;
   GX[2][0] = -1; GX[2][1] = 0; GX[2][2] = 1;

   /* 3x3 GY Sobel mask.  Ref: www.cee.hw.ac.uk/hipr/html/sobel.html */
   GY[0][0] =  1; GY[0][1] =  2; GY[0][2] =  1;
   GY[1][0] =  0; GY[1][1] =  0; GY[1][2] =  0;
   GY[2][0] = -1; GY[2][1] = -2; GY[2][2] = -1;

   /*---------------------------------------------------
		SOBEL ALGORITHM STARTS HERE
   ---------------------------------------------------*/
   for(Y=0; Y<=(IMAGE_ROWS-1); Y++)  {
	for(X=0; X<=(IMAGE_COLUMNS-1); X++)  {
	     sumX = 0;
	     sumY = 0;

             /* image boundaries */
	     if(Y==0 || Y==IMAGE_ROWS-1) {
		  SUM = 0;
	     } else if(X==0 || X==IMAGE_COLUMNS-1) {
		  SUM = 0;

	     /* Convolution starts here */
	     } else   {
		    /*-------X, Y GRADIENT APPROXIMATION------*/
#if 1
	    	/* Choice 1: No loop */
            sumX = sumX + (int)(ip1[Y][X]) * GX[1][1];//
            sumX = sumX + (int)(ip1[Y-1][X]) * GX[1][0];
            sumX = sumX + (int)(ip1[Y+1][X]) * GX[1][2];
            sumX = sumX + (int)(ip1[Y][X-1]) * GX[0][1];//
            sumX = sumX + (int)(ip1[Y][X+1]) * GX[2][1];//
            sumX = sumX + (int)(ip1[Y-1][X-1]) * GX[0][0];
            sumX = sumX + (int)(ip1[Y-1][X+1]) * GX[2][0];
            sumX = sumX + (int)(ip1[Y+1][X-1]) * GX[0][2];
            sumX = sumX + (int)(ip1[Y+1][X+1]) * GX[2][2];
            sumY = sumY + (int)(ip1[Y][X]) * GY[1][1];//
            sumY = sumY + (int)(ip1[Y-1][X]) * GY[1][0];//
            sumY = sumY + (int)(ip1[Y+1][X]) * GY[1][2];//
            sumY = sumY + (int)(ip1[Y][X-1]) * GY[0][1];
            sumY = sumY + (int)(ip1[Y][X+1]) * GY[2][1];
            sumY = sumY + (int)(ip1[Y-1][X-1]) * GY[0][0];
            sumY = sumY + (int)(ip1[Y-1][X+1]) * GY[2][0];
            sumY = sumY + (int)(ip1[Y+1][X-1]) * GY[0][2];
            sumY = sumY + (int)(ip1[Y+1][X+1]) * GY[2][2];
#endif
#if 0
            /* Choice 2: One loop */
	       for(I=-1; I<=1; I++)  {
		   for(J=-1; J<=1; J++)  {
		      sumX = sumX + (int)(ip1[Y+J][X+I]) * GX[I+1][J+1];
		       sumY = sumY + (int)(ip1[Y+J][X+I]) * GY[I+1][J+1];
		   }
	       }
#endif
#if 0
	       /* Choice 3: Two loops */
	       /*-------X GRADIENT APPROXIMATION------*/
	       for(I=-1; I<=1; I++)  {
		   for(J=-1; J<=1; J++)  {
		      sumX = sumX + (int)(ip1[Y+J][X+I]) * GX[I+1][J+1];
		   }
	       }

	       /*-------Y GRADIENT APPROXIMATION-------*/
	       for(I=-1; I<=1; I++)  {
		   for(J=-1; J<=1; J++)  {
		       sumY = sumY + (int)(ip1[Y+J][X+I]) * GY[I+1][J+1];
		   }
	       }
#endif
	       /*---GRADIENT MAGNITUDE APPROXIMATION (Myler p.218)----*/
           SUM = abs(sumX) + abs(sumY);
         }

         if(SUM>255) SUM=255;
         if(SUM<0) SUM=0;

         *(outputImg + X + Y*IMAGE_COLUMNS) = (BYTE)1;
	  }
   }
}
