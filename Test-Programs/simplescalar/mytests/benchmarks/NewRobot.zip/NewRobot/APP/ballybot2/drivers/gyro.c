#include <includes.h>
#include  <stdlib.h>
/* --- ARM PORT ---*/
int gyroRawValue;
int gyro_pre_count;
/* --- ARM PORT ---*/

int gy_middle = 0;

void gyroInit(ServoHandle gyroName){
 
  //Call ARM PORT function
  //GYRO_Init();
  GYRO_Init_Timer();
  /*Initialize static servo signal to the gyro*/
  SERVOSet(gyroName,128);	/*set servo signal to middle position*/  
}
int accreadY() {
    //printf("\nCurrent Gyro value: %d",gyroRawValue);
    return gyroRawValue;
}

int gyroRaw()
{
  int gyRaw;

  gyRaw = accreadY();
  // LCDPrintf("GYraw:%d\n",gyRaw);
  printf("\ngy=%d", gyRaw);

  return gyRaw;
}

float gyVelocity(){

 float velocity = 0;
 int raw = 0;
 
 raw = accreadY();
 velocity = (raw - gy_middle)*0.002798;

 return velocity;
}

void gyroMiddle(){

int  initial = 0;
 int i;

  for(i=0;i<10;i++){
    initial+=accreadY();
    OSTimeDly((unsigned)(0.1*OS_TICKS_PER_SEC));
  }
  gy_middle = initial/10;
  D(printf("GY middle:%d",gy_middle));
}

/* ARM Porting function */
void GYRO_Init(void) //using GPIO_1_19 (Pin J9-33 APF28Dev Kit)
{
   // Set HW_PINCTRL_MUXSELx (set bit 6 and 7)
   writel(0x000000C0, HW_PINCTRL_MUXSEL3_SET);
   // Enable input
   writel(GYRO_MASK, HW_PINCTRL_DOE1_CLR);
   // Set the HW_PINCTRL_PULLx (enable pull up resister)
   writel(GYRO_MASK, HW_PINCTRL_PULL1_SET);
   // Edge detection
   writel(GYRO_MASK, HW_PINCTRL_IRQLEVEL1_CLR);   
   // falling edge detection
   writel(GYRO_MASK, HW_PINCTRL_IRQPOL1_CLR);
   // Clear interrupt
   writel(GYRO_MASK, HW_PINCTRL_IRQSTAT1_CLR);
   // Enable as interrupt pin
   writel(GYRO_MASK, HW_PINCTRL_PIN2IRQ1_SET);
   // Enable the interrupt signal back to Interrupt Collector
   writel(GYRO_MASK, HW_PINCTRL_IRQEN1_SET);  

   /*Setup PPM interrupt*/
   ICOLL_SetupIntr(GYRO_Interrupt_Handler, 0, INT_PINCTRL1, LEVEL3);
   /*Enable Interrupt in ICOLL*/
   ICOLL_EnableIntr(INT_PINCTRL1);     

   gyro_pre_count=T10kHz_count; //Initialize first checkpoint
   D(printf("\nInitialize GYRO successfully"));
}

/* ARM Porting function */
void GYRO_Init_Timer(void) //using Timer 2
{
  writel((1<<4) | (1<<5), HW_TIMROT_TIMCTRL2_CLR); //PRESCALE = 0;
  writel(1<<6, HW_TIMROT_TIMCTRL2_SET);	//RELOAD = 1;
  writel(1<<7, HW_TIMROT_TIMCTRL2_CLR);	//UPDATE = 0;
  writel(1<<14, HW_TIMROT_TIMCTRL2_SET); //IRQ_EN = 1;
  writel(TIMER_CLOCK_FREQ/1000, HW_TIMROT_FIXED_COUNT2); //1kHz

  /*Setup Timer 2 interrupt*/
  ICOLL_SetupIntr(GYRO_Timer_Interrupt_Handler, 0, INT_TIMER2, LEVEL2);
  /*Enable Interrupt in ICOLL*/
  ICOLL_EnableIntr(INT_TIMER2);
  /*Start timer. Clock from 24MHz*/  
  writel(0x0F, HW_TIMROT_TIMCTRL2_SET); //SELECT = 0xF;
  D(printf("\nInitialize GYRO successfully"));
}

static unsigned int r_num = 7621;

void  GYRO_Timer_Interrupt_Handler (void)
{   
    int count;

#if (TASK_TO_MEASURE == 6)
	START_MEASURE();
#endif

  // Clear interrupt flag
  writel(1<<15, HW_TIMROT_TIMCTRL2_CLR);  
  // Update pseudo-gyro value (fixed)
  //gyroRawValue=1000;
    count = T10kHz_count;
   gyroRawValue=(count-gyro_pre_count)*100; //Normalize gyro value
   gyro_pre_count=count; //Update newest checkpoint

   r_num = ((r_num*7621) + 1) % 32768;
   gyroRawValue = (r_num % 101) - 50;
#if (TASK_TO_MEASURE == 6)
   END_MEASURE();
#endif
}

void  GYRO_Interrupt_Handler (void)
{
   // Clear interrupt flag
   writel(GYRO_MASK, HW_PINCTRL_IRQSTAT1_CLR); 
   gyroRawValue=(T10kHz_count-gyro_pre_count)*100; //Normalize gyro value
   gyro_pre_count=T10kHz_count; //Update newest checkpoint
   
}
