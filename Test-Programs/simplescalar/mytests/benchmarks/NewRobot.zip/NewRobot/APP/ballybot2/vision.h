#ifndef  VISION_H
#define  VISION_H

#include <includes.h>

void IPSobel(image *ip1, image *ip2);

#endif
