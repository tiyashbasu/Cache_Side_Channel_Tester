#ifndef  ENCODER_H
#define  ENCODER_H

#define QUAD_UNDEFINE 0
#define QUAD_L  1
#define QUAD_R  2

#define MAX_COUNTER 2000000000 //2 billions of tick

/*Initialize given quad*/
int QUADInit(Device dev);
/*Release given quad*/
int QUADRelease(QuadHandle dev);
/*Reset given quad*/
int QUADReset(QuadHandle dev);
/*Read given quad*/
int QUADRead(QuadHandle dev);
/*Initialize left Encoder - Using Timer 2, PWM6 as input signal*/
void Quad_Left_Init(void);
/*Initialize Right Encoder - Using Timer 3, PWM7 as input signal*/
void Quad_Right_Init(void);

#endif
