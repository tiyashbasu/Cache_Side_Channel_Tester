#ifndef  INCLINO_H
#define  INCLINO_H

#define INCLINO_MASK	1<<19	// Input from Inclino sensor

int NewDataX;

void inclinoInit();
int accreadX();

/*
 * Reads TPU7 and convert inclinometer value to angle
 */
float incAngle();

/*
 *Returns the inclino raw value
 */
int incRaw();

/* ARM Porting functions */
void INCLINO_Init(void); //using GPIO_1_19 (Pin J9-33 APF28Dev Kit)
void INCLINO_Init_Timer(void);
void INCLINO_Interrupt_Handler (void);
void  INCLINO_Timer_Interrupt_Handler (void);


#endif
