#ifndef  CAMERA_H
#define  CAMERA_H

#define IMAGE_COLUMNS 80
#define IMAGE_ROWS 60

//#define IMAGE_COLUMNS 60
//#define IMAGE_ROWS 40

#define NORMAL 0 

#define INITERROR 1
#define NOCAM 2 

#define START_IMAGE_BUFFER_ADDR 0x40040000 //First 512KB of RAM: 1)256KB for program 2)256KB for Image buffer
//#define IMAGE_FRAME_SIZE 	15252	   //82*62*3=15252 bytes
#define IMAGE_FRAME_SIZE 	4800	   //80*60=4800 bytes
//#define IMAGE_FRAME_SIZE 	2400	   //60*40=2400 bytes

int CAMInit(int mode);
void CAMGetFrame(image *buf);
void CAMGetColFrame(BYTE buf[IMAGE_ROWS][IMAGE_COLUMNS][3], int convert);
int CAMRelease(void);

#endif
