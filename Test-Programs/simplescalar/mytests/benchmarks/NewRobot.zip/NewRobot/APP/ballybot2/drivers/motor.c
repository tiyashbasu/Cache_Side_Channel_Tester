#include <includes.h>
int motor_left_direction;  //current direction of motor left
int motor_right_direction; //current direction of motor right

/*Initialize given motor*/
int MOTORInit(Device dev){
MotorHandle handle=MOTOR_UNDEFINE;
  switch(dev)
  {
    case MOTOR_LEFT:
        Motor_Left_Init();
        motor_left_direction=DIRECTION_NO_MOVE;	
	handle=MOTOR_L;
        D(printf("\nInitialize MOTOR LEFT successfully"));
	break;
    case MOTOR_RIGHT:
        Motor_Right_Init();
        motor_right_direction=DIRECTION_NO_MOVE;	
	handle=MOTOR_R;
        D(printf("\nInitialize MOTOR RIGHT successfully"));
	break;
    default:	
	break;
  }
  
return handle;
}
/*Set the given motors to the same given speed*/
int MOTORDrive (MotorHandle dev,int speed){
int direction;
Int32U value;
//Normalize speed
if(speed>0){
  direction=DIRECTION_MOVE_FORWARD;
}else if(speed==0){
  direction=DIRECTION_NO_MOVE;
}else if(speed<0){
  speed=0-speed;
  direction=DIRECTION_MOVE_BACKWARD;
}
//Control motor
//Calculate in-active value for HW_PWM_ACTIVEx register
value=(Int32U)speed*240; //value=(speed/100)*24000=speed*240
value=value<<16;
  switch(dev)
  {
    case MOTOR_L:        
        motor_left_direction=direction; //Update direction
	writel(1<<5, HW_PWM_CTRL_CLR); //Disable PWM5 temporarily   
  	// Setup PWM channels
  	writel(value, HW_PWM_ACTIVE5); //ALWAYS Low
  	writel(0x000E5DBF, HW_PWM_PERIOD5); //24000 ticks    
  	writel(1<<5, HW_PWM_CTRL_SET); //Enable PWM5
	break;
    case MOTOR_R:
        motor_right_direction=direction; //Update direction
        writel(1<<3, HW_PWM_CTRL_CLR); //Disable PWM3 temporarily   
  	// Setup PWM channels
  	writel(value, HW_PWM_ACTIVE3); //ALWAYS Low
  	writel(0x000E5DBF, HW_PWM_PERIOD3); //24000 ticks    
  	writel(1<<3, HW_PWM_CTRL_SET); //Enable PWM3
	break;
    default:
	return -1; //ERROR
	break;
  }
return 0;
}
/*Release given servos*/
int MOTORRelease(MotorHandle dev){
  switch(dev)
  {
    case MOTOR_L:
        writel(1<<5, HW_PWM_CTRL_CLR); //Disable PWM5
	break;
    case MOTOR_R:
        writel(1<<3, HW_PWM_CTRL_CLR); //Disable PWM3
	break;
    default:
	return -1; //ERROR
	break;
  }
return 0;
}

/*Initialize right motor, using PWM5 channel to control the motor*/
void Motor_Left_Init(void) //PWM5 (J9-Pin5-APF28Dev Kit)
{
  volatile int i;  
  // Choose PWM function
  writel(1<<12, HW_PINCTRL_MUXSEL7_SET); 
  writel(1<<13, HW_PINCTRL_MUXSEL7_CLR);
  // Set the HW_PINCTRL_DRIVEx (3.3V, 8mA)
  writel(0x00500000, HW_PINCTRL_DRIVE14_SET);
  // Set the HW_PINCTRL_PULLx (no pull up resister)
  writel(1<<22, HW_PINCTRL_PULL3_SET);
  // Enable ouput
  writel(1<<22, HW_PINCTRL_DOE3_SET); 
  // Ouput HIGH
  writel(1<<22, HW_PINCTRL_DOUT3_SET);

  // Enable the clock for PWM block
  writel(1<<29 | 1 <<30, HW_CLKCTRL_XTAL_CLR);
  
  // Reset PWM
  writel(1<<31, HW_PWM_CTRL_SET); //SFTRST = 1;
  for(i = 100; i; i--);
  writel(1<<31, HW_PWM_CTRL_CLR); //SFTRST = 0;
  // Enable clock
  for(i = 100; i; i--);
  writel(1<<30, HW_PWM_CTRL_CLR); //CLKGATE = 0;
 
  writel(1<<5, HW_PWM_CTRL_CLR); //Disable PWM5 temporarily 
  
  // Setup PWM channels
  writel(0x00000000, HW_PWM_ACTIVE3); //ALWAYS Low
  writel(0x000E5DBF, HW_PWM_PERIOD3); //24000 ticks    

  writel(1<<5, HW_PWM_CTRL_SET); //Enable PWM5  
}


/*Initialize left motor, using PWM3 channel to control the motor*/
void Motor_Right_Init(void) //PWM3 (J9-Pin8-APF28Dev Kit)
{
  volatile int i;  
  // Choose PWM function
  writel(1<<8, HW_PINCTRL_MUXSEL7_SET); 
  writel(1<<9, HW_PINCTRL_MUXSEL7_CLR);
  // Set the HW_PINCTRL_DRIVEx (3.3V, 8mA)
  writel(0x00005000, HW_PINCTRL_DRIVE14_SET);
  // Set the HW_PINCTRL_PULLx (no pull up resister)
  writel(1<<20, HW_PINCTRL_PULL3_SET);
  // Enable ouput
  writel(1<<20, HW_PINCTRL_DOE3_SET); 
  // Ouput HIGH
  writel(1<<20, HW_PINCTRL_DOUT3_SET);

  // Enable the clock for PWM block
  writel(1<<29 | 1 <<30, HW_CLKCTRL_XTAL_CLR);
  
  // Reset PWM
  writel(1<<31, HW_PWM_CTRL_SET); //SFTRST = 1;
  for(i = 100; i; i--);
  writel(1<<31, HW_PWM_CTRL_CLR); //SFTRST = 0;
  // Enable clock
  for(i = 100; i; i--);
  writel(1<<30, HW_PWM_CTRL_CLR); //CLKGATE = 0;
 
  writel(1<<3, HW_PWM_CTRL_CLR); //Disable PWM3 temporarily 
  
  // Setup PWM channels
  writel(0x00000000, HW_PWM_ACTIVE3); //ALWAYS Low
  writel(0x000E5DBF, HW_PWM_PERIOD3); //24000 ticks    

  writel(1<<3, HW_PWM_CTRL_SET); //Enable PWM3
}

