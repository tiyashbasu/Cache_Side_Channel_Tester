#ifndef TIMER_H
#define TIMER_H

#include <includes.h>

//extern Int32U T10kHz_count;
#define T10kHz_count (10000/OS_TICKS_PER_SEC)*OSTimeGet() 

void   Tmr_10kHzInit(void);
void   Tmr_10kHz_Handler(void);
void   Tmr_1MHzInit(void);
void   Tmr_1MHz_Handler(void);
unsigned int    getCurrent1MHzCount();
unsigned int    getCurrent24MHzCount();

#endif
