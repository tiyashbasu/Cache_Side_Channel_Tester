#ifndef  GYRO_H
#define  GYRO_H
#include <includes.h>

#define GYRO    3
#define SERVO   4

#define GYRO_MASK	1<<19	// Input from Gyro sensor

int NewDataY;

void gyroInit(ServoHandle gyroName);
int accreadY();

/*
 *Returns the gyro raw value
 */
int gyroRaw();

float gyVelocity();

void gyroMiddle();

/*ARM Porting function */
void GYRO_Init(void); //using GPIO_1_19 (Pin J9-33 APF28Dev Kit)
void GYRO_Init_Timer(void);
void  GYRO_Interrupt_Handler (void);
void  GYRO_Timer_Interrupt_Handler (void);

#endif
