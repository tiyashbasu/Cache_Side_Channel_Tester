#include <includes.h>

/* --- ARM PORT ---*/
int inclinoRawValue;
int inclino_pre_count;
/* --- ARM PORT ---*/

#define FACTOR 0.000580479; //converts inclino to radians
int midValue = 0;

void inclinoInit(){
  int i;
  int initial= 0;
  
  //Call ARM PORT function
  //INCLINO_Init();
  INCLINO_Init_Timer();

  OSTimeDly((unsigned)(2.0*OS_TICKS_PER_SEC));
  for(i=0;i<10;i++){
    initial += accreadX();
    OSTimeDly((unsigned)(0.2*OS_TICKS_PER_SEC));
  }
  midValue = initial/10;
  D(printf("inclino middle value is:%d\n",midValue));
  D(printf("inclino Init Complete\n")); 
}

int accreadX() {
    //printf("\nCurrent Inclino value: %d",inclinoRawValue);
    return inclinoRawValue;
}

/*
 * Reads TPU7 and convert inclinometer value to angle
 * in radians
 */
float incAngle(){
  int rawValue;
  float angle;

  rawValue = accreadX();
  printf("\nin=%d", rawValue);
  angle =(rawValue - midValue)*FACTOR;
  //printf("Angle:%.d\n",(int)angle*10);
  //D(printf("Angle:%.d\n",(int)angle));
  //D(printf("Raw:%d\n",rawValue));
  return angle;
}

/*
 *Returns the inclino raw value
 */
int incRaw(){

  int inRaw;
  inRaw = accreadX();
  return inRaw;
}

/* ARM Porting functions */
void INCLINO_Init(void) //using GPIO_2_19 (Pin J10-25 APF28Dev Kit)
{
   // Set HW_PINCTRL_MUXSELx (set bit 6 and 7)
   writel(0x000000C0, HW_PINCTRL_MUXSEL5_SET);
   // Enable input
   writel(INCLINO_MASK, HW_PINCTRL_DOE2_CLR);
   // Set the HW_PINCTRL_PULLx (enable pull up resister)
   writel(INCLINO_MASK, HW_PINCTRL_PULL2_SET);
   // Edge detection
   writel(INCLINO_MASK, HW_PINCTRL_IRQLEVEL2_CLR);   
   // falling edge detection
   writel(INCLINO_MASK, HW_PINCTRL_IRQPOL2_CLR);
   // Clear interrupt
   writel(INCLINO_MASK, HW_PINCTRL_IRQSTAT2_CLR);
   // Enable as interrupt pin
   writel(INCLINO_MASK, HW_PINCTRL_PIN2IRQ2_SET);
   // Enable the interrupt signal back to Interrupt Collector
   writel(INCLINO_MASK, HW_PINCTRL_IRQEN2_SET);  
   
   /*Setup PPM interrupt*/
   ICOLL_SetupIntr(INCLINO_Interrupt_Handler, 0, INT_PINCTRL2, LEVEL3);
   /*Enable Interrupt in ICOLL*/
   ICOLL_EnableIntr(INT_PINCTRL2);      

   inclino_pre_count=T10kHz_count; //Initialize first checkpoint
   D(printf("\nInitialize INCLINO successfully"));
}
void  INCLINO_Interrupt_Handler (void)
{
   // Clear interrupt flag
   writel(INCLINO_MASK, HW_PINCTRL_IRQSTAT2_CLR); 
   inclinoRawValue=(T10kHz_count-inclino_pre_count)*100; //Normalize gyro value
   inclino_pre_count=T10kHz_count; //Update newest checkpoint
}

/* ARM Porting function */
void INCLINO_Init_Timer(void) //using Timer 3
{
  writel((1<<4) | (1<<5), HW_TIMROT_TIMCTRL3_CLR); //PRESCALE = 0;
  writel(1<<6, HW_TIMROT_TIMCTRL3_SET);	//RELOAD = 1;
  writel(1<<7, HW_TIMROT_TIMCTRL3_CLR);	//UPDATE = 0;
  writel(1<<14, HW_TIMROT_TIMCTRL3_SET); //IRQ_EN = 1;
  writel(TIMER_CLOCK_FREQ/1000, HW_TIMROT_FIXED_COUNT3); //1kHz

  /*Setup Timer 3 interrupt*/
  ICOLL_SetupIntr(INCLINO_Timer_Interrupt_Handler, 0, INT_TIMER3, LEVEL2);
  /*Enable Interrupt in ICOLL*/
  ICOLL_EnableIntr(INT_TIMER3);
  /*Start timer. Clock from 24MHz*/  
  writel(0x0F, HW_TIMROT_TIMCTRL3_SET); //SELECT = 0xF;
  D(printf("\nInitialize INCLINO successfully"));
}

static unsigned int r_num = 3217;

void  INCLINO_Timer_Interrupt_Handler (void)
{
    int count;

#if (TASK_TO_MEASURE == 7)
	START_MEASURE();
#endif

  // Clear interrupt flag
  writel(1<<15, HW_TIMROT_TIMCTRL3_CLR);

  // Update pseudo-gyro value (fixed)
  //inclinoRawValue=1000;

   count = T10kHz_count;
   inclinoRawValue=(count-inclino_pre_count)*100; //Normalize gyro value
   inclino_pre_count=count; //Update newest checkpoint

   r_num = ((r_num*7621) + 1) % 32768;
   inclinoRawValue = (r_num % 101) - 50;
#if (TASK_TO_MEASURE == 7)
	END_MEASURE();
#endif
}
