#ifndef  IRTV_H
#define  IRTV_H

/* control codes for Nokia VCN620 */

#define RC_0      		0x6142
#define RC_1      		0x61fd
#define RC_2      		0x6102
#define RC_3      		0x60fd
#define RC_4      		0x6082
#define RC_5      		0x617d
#define RC_6      		0x6182
#define RC_7      		0x607d
#define RC_8      		0x6042
#define RC_9      		0x61bd

#define RC_STANDBY		0x61a2
#define RC_PLUS			0x61dd
#define RC_MINUS		0x6122
#define RC_CLEAR		0x6012
#define RC_TIMER		0x619d

#define RC_PLAY			0x6112
#define RC_STOP			0x606d
#define RC_FF			0x61ed
#define RC_RW			0x60ed
#define RC_OK			0x6166

#define RC_RED			0x61ad
#define RC_GREEN		0x616d
#define RC_YELLOW		0x6032
#define RC_BLUE			0x602d

#define RC_RECORD		0x6052
#define RC_CLOCK		0x61c2
#define RC_SETUP		0x6066
#define RC_INFO			0x60c6

//#define IRTV_MASK		1<<19// Input from IR receiver
#define IRTV_MASK		1<<17// Input from user switch on APF28-Dev (to simulate remote command)

#define IRTV_NB_PULSES		16	// Each data packet is 16 bits
extern Int16U irtv_masks[ IRTV_NB_PULSES ];

Int16U IRTVRead (void);
void IRTV_Init( void );
void IRTV_Interrupt_Handler (void);

#endif
