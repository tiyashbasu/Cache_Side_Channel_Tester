#ifndef  MOTOR_H
#define  MOTOR_H
#include <includes.h>

#define MOTOR_UNDEFINE 0
#define MOTOR_L 1
#define MOTOR_R 2

#define DIRECTION_MOVE_BACKWARD -1
#define DIRECTION_MOVE_FORWARD   1
#define DIRECTION_NO_MOVE        0

extern int motor_left_direction;
extern int motor_right_direction;

/*Initialize given motor*/
int MOTORInit(Device dev);
/*Set the given motors to the same given speed*/
int MOTORDrive (MotorHandle dev,int speed);
/*Release given servos*/
int MOTORRelease(MotorHandle dev);
/*Initialize left motor, using PWM3 channel to control the motor*/
void Motor_Left_Init(void); //PWM3 (J9-Pin8-APF28Dev Kit)
/*Initialize right motor, using PWM4 channel to control the motor*/
void Motor_Right_Init(void); //PWM4 (J9-Pin7-APF28Dev Kit)
#endif
