#include <includes.h>
#include <string.h>

  /*
Input:  (mode) camera initialization mode
Valid Values are: NORMAL
Output:  (return code) Camera version or Error code
Valid values: 
255     = no camera connected //NOCAM
200..254= camera init error (200 + cam. code)//INITERROR
otherwise
Semantics:      Reset and initialize connected camera
   */
int CAMInit(int mode){
D(printf("\nInitialize CAMERA successfully"));
return 0; //Initialize successfully
}

void CAMGetFrame(image *buf)
{
    int count=IMAGE_FRAME_SIZE;
    BYTE *tmp = (BYTE *) buf;

	while (count--){
		*(tmp+count) = 1;//*tmp++ = *s++;		
	}
}


  /*
Input:          (buf) a pointer to a color image 
(convert) flag if image should be reduced to 8 bit gray
0 = get 24bit color image // NO
1 = get 8bit grayscale image // YES
Output:         NONE
Semantics:      Read an image size 82x62 from color cam and reduce it
if required to 8 bit gray scale.
   */
void CAMGetColFrame(BYTE buf[IMAGE_ROWS][IMAGE_COLUMNS][3], int convert)
{
    //ALWAYS get RGB image from Image buffer 
    //memcpy((unsigned char *)buf, (unsigned char *)START_IMAGE_BUFFER_ADDR, IMAGE_FRAME_SIZE);

    //int count=IMAGE_FRAME_SIZE;
    //BYTE *tmp = (BYTE *) buf;

    //BYTE *s = (BYTE *)START_IMAGE_BUFFER_ADDR ;

	/*while (count--){
		*tmp++ = *s++;		
	}*/

    int i, j, k;
    for (i=0; i<IMAGE_ROWS; i++)
        for (j=0; j<IMAGE_COLUMNS; j++)
            for (k=0; k<3; k++)
                buf[i][j][k] = i+j+k;//*s++; 
}

  /*
Input:          NONE
Output:         (return code) 
0 = success
-1 = error
   */
int CAMRelease(void){
return 0; //Release successfully
}
