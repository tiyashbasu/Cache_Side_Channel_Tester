#include <includes.h>

/*Initialize given gyro servo control by PWM4 (J9-Pin7-APF28Dev Kit)*/
int SERVOInit(){
  volatile int i;
  // Choose PWM function
  writel(1<<10, HW_PINCTRL_MUXSEL7_SET); //PWM_4
  writel(1<<11, HW_PINCTRL_MUXSEL7_CLR); 
  // Set the HW_PINCTRL_DRIVEx (3.3V, 8mA)
  writel(0x00050000, HW_PINCTRL_DRIVE14_SET);
  // Set the HW_PINCTRL_PULLx (no pull up resister)
  writel(1<<21, HW_PINCTRL_PULL3_SET);
  // Enable ouput
  writel(1<<21, HW_PINCTRL_DOE3_SET);
  // Ouput HIGH
  writel(1<<21, HW_PINCTRL_DOUT3_SET);

  // Enable the clock for PWM block
  writel(1<<29 | 1 <<30, HW_CLKCTRL_XTAL_CLR);
  
   /* Reset PWM module*/
  writel(1<<31, HW_PWM_CTRL_SET); //SFTRST = 1;
  for(i = 100; i; i--);
  writel(1<<31, HW_PWM_CTRL_CLR); //SFTRST = 0;
  /* Enable clock*/ 
  for(i = 100; i; i--);
  writel(1<<30, HW_PWM_CTRL_CLR); //CLKGATE = 0; 
  
  writel(1<<4, HW_PWM_CTRL_CLR); //Disable PWM4 temporarily  
  
  // Setup PWM channels
  writel(0x00000000, HW_PWM_ACTIVE4); //ALWAYS Low
  writel(0x000E5DBF, HW_PWM_PERIOD4); //24000 ticks    
  
  writel(1<<4, HW_PWM_CTRL_SET); //Enable PWM4    

  D(printf("\nInitialize SERVO successfully")); 
return 0;
}

/*Set the given servos to the same given angle*/
int SERVOSet (ServoHandle dev, int angle){
float ratio;
Int32U value;
  //Calculate in-active value for HW_PWM_ACTIVEx register
  ratio=angle/256;
  value=(Int32U)(24000*ratio); //value=(angle/256)*24000
  value=value<<16;

  //Control servo
  writel(1<<4, HW_PWM_CTRL_CLR); //Disable PWM4 temporarily   
  // Setup PWM channels
  writel(value, HW_PWM_ACTIVE5); //ALWAYS Low
  writel(0x000E5DBF, HW_PWM_PERIOD5); //24000 ticks    
  writel(1<<4, HW_PWM_CTRL_SET); //Enable PWM4
return 0;
}

/*Release given servos*/
int SERVORelease(ServoHandle dev){
  writel(1<<4, HW_PWM_CTRL_CLR); //Disable PWM5
return 0;
}

