#include <includes.h>
int encoder_left_pre_value, encoder_left_cur_value;
int encoder_right_pre_value, encoder_right_cur_value;

/*Initialize given quad*/
int QUADInit(Device dev){
QuadHandle handle=QUAD_UNDEFINE;
  switch(dev)
  {
    case QUAD_LEFT:
        //Quad_Left_Init();      
        //encoder_left_pre_value=MAX_COUNTER; 
	handle=QUAD_L;
        D(printf("\nInitialize ENCODER LEFT successfully"));
	break;
    case QUAD_RIGHT:
        //Quad_Right_Init();   
        //encoder_right_pre_value=MAX_COUNTER;     	
	handle=QUAD_R;
        D(printf("\nInitialize MOTOR RIGHT successfully"));
	break;
    default:	
	break;
  }
return handle;
}
/*Release given quad*/
int QUADRelease(QuadHandle dev){
return 0;
}
/*Reset given quad*/
int QUADReset(QuadHandle dev){
//encoder_left_pre_value=readl(HW_TIMROT_RUNNING_COUNT2);
//encoder_right_pre_value=readl(HW_TIMROT_RUNNING_COUNT3);
encoder_left_pre_value=1;
encoder_right_pre_value=1;
return 0;
}
/*Read given quad*/
int QUADRead(QuadHandle dev){
int quadValue;
switch(dev)
  {
    case QUAD_L:
	encoder_left_cur_value=readl(HW_TIMROT_RUNNING_COUNT2);
	if((motor_left_direction==DIRECTION_MOVE_FORWARD) || (motor_left_direction==DIRECTION_NO_MOVE) ){
        	quadValue=encoder_left_pre_value-encoder_left_cur_value;
	} else if(motor_left_direction==DIRECTION_MOVE_FORWARD) {
		quadValue=encoder_left_cur_value-encoder_left_pre_value;
	}
	encoder_left_pre_value=encoder_left_cur_value; //Update newest check point
	break;
    case QUAD_R:
        encoder_right_cur_value=readl(HW_TIMROT_RUNNING_COUNT3);
	if((motor_right_direction==DIRECTION_MOVE_FORWARD) || (motor_right_direction==DIRECTION_NO_MOVE) ){
        	quadValue=encoder_right_pre_value-encoder_right_cur_value;
	} else if(motor_left_direction==DIRECTION_MOVE_FORWARD) {
		quadValue=encoder_right_cur_value-encoder_right_pre_value;
	}
        encoder_right_pre_value=encoder_right_cur_value; //Update newest check point
	break;
    default:	
	break;
  }
//return quadValue;
return 1;
}
/*Initialize left Encoder - Using Timer 2, PWM6 as input signal*/
void Quad_Left_Init(void)
{
  // Enable PWM6 working as GPIO input pin 
  // Clear HW_PINCTRL_MUXSELx (bit 24 and 25)
  writel(1<<14 | 1<<15, HW_PINCTRL_MUXSEL7_SET);  
  // Enable input
  writel(1<<23, HW_PINCTRL_DOE3_CLR);
  // Set the HW_PINCTRL_PULLx (enable pull up resister)
  writel(1<<23, HW_PINCTRL_PULL3_SET);    

  // Setup Timer 2
  writel((1<<4) | (1<<5), HW_TIMROT_TIMCTRL2_CLR); //PRESCALE = 0;
  writel(1<<6, HW_TIMROT_TIMCTRL2_SET);	//RELOAD = 1;
  writel(1<<7, HW_TIMROT_TIMCTRL2_SET);	//UPDATE = 1;  
  writel(MAX_COUNTER, HW_TIMROT_FIXED_COUNT2);//Set initial counter  
  /*Start timer. Clock from PWM6*/  
  writel(0x0F, HW_TIMROT_TIMCTRL2_CLR); //SELECT = 0x07; 
  writel(0x07, HW_TIMROT_TIMCTRL2_SET); //SELECT = 0x07;  
}
/*Initialize Right Encoder - Using Timer 3, PWM7 as input signal*/
void Quad_Right_Init(void)
{
  // Enable PWM7 working as GPIO input pin 
  // Clear HW_PINCTRL_MUXSELx (bit 24 and 25)
  writel(1<<20 | 1<<21, HW_PINCTRL_MUXSEL7_SET);  
  // Enable input
  writel(1<<26, HW_PINCTRL_DOE3_CLR);
  // Set the HW_PINCTRL_PULLx (enable pull up resister)
  writel(1<<26, HW_PINCTRL_PULL3_SET);    

  // Setup Timer 2
  writel((1<<4) | (1<<5), HW_TIMROT_TIMCTRL3_CLR); //PRESCALE = 0;
  writel(1<<6, HW_TIMROT_TIMCTRL3_SET);	//RELOAD = 1;
  writel(1<<7, HW_TIMROT_TIMCTRL3_SET);	//UPDATE = 1;  
  writel(MAX_COUNTER, HW_TIMROT_FIXED_COUNT3);//Set initial counter  
  /*Start timer. Clock from PWM7*/  
  writel(0x0F, HW_TIMROT_TIMCTRL3_CLR); //SELECT = 0x08; 
  writel(0x08, HW_TIMROT_TIMCTRL3_SET); //SELECT = 0x08;  
}



