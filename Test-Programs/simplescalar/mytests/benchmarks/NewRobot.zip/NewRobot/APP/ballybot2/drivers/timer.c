#include <includes.h>

//Int32U T10kHz_count; //10kHz
static unsigned int bias; //Bias because of timer reload after reach 0

// Fast 10kHz clock for capture PPM signal (Timer 1)
void Tmr_10kHzInit(void)
{
  writel((1<<4) | (1<<5), HW_TIMROT_TIMCTRL1_CLR); //PRESCALE = 0;
  writel(1<<6, HW_TIMROT_TIMCTRL1_SET);	//RELOAD = 1;
  writel(1<<7, HW_TIMROT_TIMCTRL1_CLR);	//UPDATE = 0;
  writel(1<<14, HW_TIMROT_TIMCTRL1_SET); //IRQ_EN = 1;
  writel(TIMER_CLOCK_FREQ / 10000, HW_TIMROT_FIXED_COUNT1);

  /*Setup Timer 0 interrupt*/
  ICOLL_SetupIntr(Tmr_10kHz_Handler, 0, INT_TIMER1, LEVEL2);
  /*Enable Interrupt in ICOLL*/
  ICOLL_EnableIntr(INT_TIMER1);
  /*Start timer. Clock from 24MHz*/  
  writel(0x0F, HW_TIMROT_TIMCTRL1_SET); //SELECT = 0xF;
  
  //T10kHz_count=0;
}

// 10kHz Timer interrupt handler
void  Tmr_10kHz_Handler (void)
{
    // Clear interrupt flag
    writel(1<<15, HW_TIMROT_TIMCTRL1_CLR);  
    //T10kHz_count++;     
    //LED_TOGGLE();                                            
}

void Tmr_1MHzInit(void)
{
  writel((1<<4) | (1<<5), HW_TIMROT_TIMCTRL1_CLR); //PRESCALE = 0;
  writel(1<<6, HW_TIMROT_TIMCTRL1_SET);	//RELOAD = 1;
  writel(1<<7, HW_TIMROT_TIMCTRL1_CLR);	//UPDATE = 0;
  writel(1<<14, HW_TIMROT_TIMCTRL1_SET); //IRQ_EN = 1;
  writel(TIMER_CLOCK_FREQ, HW_TIMROT_FIXED_COUNT1);

  /*Setup Timer 1 interrupt*/
  ICOLL_SetupIntr(Tmr_1MHz_Handler, 0, INT_TIMER1, LEVEL2);
  /*Enable Interrupt in ICOLL*/
  ICOLL_EnableIntr(INT_TIMER1);
  /*Start timer. Clock from 24MHz*/  
  writel(0x0F, HW_TIMROT_TIMCTRL1_SET); //SELECT = 0xF;
  
  bias=0;

}

// 10kHz Timer interrupt handler
void  Tmr_1MHz_Handler (void)
{
    // Clear interrupt flag
    writel(1<<15, HW_TIMROT_TIMCTRL1_CLR);  
    bias=bias+TIMER_CLOCK_FREQ;
}

unsigned int getCurrent1MHzCount()
{
   return (TIMER_CLOCK_FREQ - readl(HW_TIMROT_RUNNING_COUNT1) + bias)/24;
}

unsigned int getCurrent24MHzCount()
{
   return (TIMER_CLOCK_FREQ - readl(HW_TIMROT_RUNNING_COUNT1) + bias);
}

