/*
*********************************************************************************************************
*                                    APPLICATION SPECIFIC RTOS SETUP
*
*                             (c) Copyright 2005, Micrium, Inc., Weston, FL
*                                          All Rights Reserved
*
*                                          CONFIGURATION FILE
*
* File : app_cfg.h
* By   : Eric Shufro
*********************************************************************************************************
*/

#ifndef  APP_CFG_H
#define  APP_CFG_H

/*
*********************************************************************************************************
*                                       INCLUDES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                      APPLICATION CONFIGURATION
*
* Note(s) : (1) Configure the product's/application's desired product configuration values.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                            TASKS PRIORITIES
*********************************************************************************************************
*/

#define  APP_TASK_START_PRIO                   1
#define  OS_USER_TASK1_PRIO                    4
#define  OS_USER_TASK2_PRIO                    8
#define  OS_USER_TASK3_PRIO                    10
#define  OS_USER_TASK4_PRIO                    12
#define  OS_USER_TASK5_PRIO                    13
#define  OS_TASK_TMR_PRIO                      18

/*
*********************************************************************************************************
*                                              STACK SIZES
*                            Size of the task stacks (# of OS_STK entries)
*********************************************************************************************************
*/

#define  APP_TASK_START_STK_SIZE              2*1024
#define  APP_TASK_BALANCE_STK_SIZE            2*1024
#define  APP_TASK_NAVIGATION_STK_SIZE         32*1024
#define  APP_TASK_REMOTE_STK_SIZE             2*1024

#endif                                     /* End of file                                              */




