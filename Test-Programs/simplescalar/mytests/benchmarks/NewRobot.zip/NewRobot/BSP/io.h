#ifndef __IO_H__
#define __IO_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef NULL
#define NULL	0
#endif

__attribute__( ( always_inline ) ) void __enable_irq(void);
__attribute__( ( always_inline ) ) void __disable_irq(void);
__attribute__( ( always_inline ) ) void __enable_cache(void);
__attribute__( ( always_inline ) ) void __disable_cache(void);

#define REG32(a)            (*(volatile unsigned int *)(a))
#define SET_REG32(v, a)     (*(volatile unsigned int *)(a) = (v))
#define readl(a)            REG32(a)
#define writel(v, a)        SET_REG32(v, a)

#endif // __IO_H__


