#ifndef __IMX286_REGS_H
#define __IMX286_REGS_H

// Define special function registers for GPIO Bank 0 (Button: pin 17, Led: pin 21, PPM_input: pin 19, 4017_ouput: pin 18, IR Remote control input: pin 19)
#define HW_PINCTRL_CTRL 	0x80018000

#define HW_PINCTRL_MUXSEL1	0x80018110
#define HW_PINCTRL_MUXSEL1_SET	0x80018114
#define HW_PINCTRL_MUXSEL1_CLR	0x80018118
#define HW_PINCTRL_MUXSEL1_TOG	0x8001811C

#define HW_PINCTRL_DRIVE2_SET	0x80018324 // For setting voltage for ouput pin

#define HW_PINCTRL_PULL0_SET	0x80018604 // For setting pull up resistors

#define HW_PINCTRL_DOUT0_SET	0x80018704 // Data ouput registers
#define HW_PINCTRL_DOUT0_CLR	0x80018708
#define HW_PINCTRL_DOUT0_TOG	0x8001870C

#define HW_PINCTRL_DOE0_SET	0x80018B04 // Data ouput enable registers
#define HW_PINCTRL_DOE0_CLR	0x80018B08

#define HW_PINCTRL_IRQLEVEL0		0x80019200 // Interrupt level/edge registers
#define HW_PINCTRL_IRQLEVEL0_SET	0x80019204
#define HW_PINCTRL_IRQLEVEL0_CLR	0x80019208
#define HW_PINCTRL_IRQLEVEL0_TOG	0x8001920C

#define HW_PINCTRL_IRQPOL0		0x80019300 // Interrupt polarity registers
#define HW_PINCTRL_IRQPOL0_SET		0x80019304
#define HW_PINCTRL_IRQPOL0_CLR		0x80019308
#define HW_PINCTRL_IRQPOL0_TOG		0x8001930C

#define HW_PINCTRL_IRQSTAT0		0x80019400 // Interrupt status registers
#define HW_PINCTRL_IRQSTAT0_SET		0x80019404
#define HW_PINCTRL_IRQSTAT0_CLR		0x80019408
#define HW_PINCTRL_IRQSTAT0_TOG		0x8001940C

#define HW_PINCTRL_PIN2IRQ0		0x80019000 // Interrupt select registers
#define HW_PINCTRL_PIN2IRQ0_SET		0x80019004
#define HW_PINCTRL_PIN2IRQ0_CLR		0x80019008
#define HW_PINCTRL_PIN2IRQ0_TOG		0x8001900C

#define HW_PINCTRL_IRQEN0		0x80019100 // Interrupt mask registers
#define HW_PINCTRL_IRQEN0_SET		0x80019104
#define HW_PINCTRL_IRQEN0_CLR		0x80019108
#define HW_PINCTRL_IRQEN0_TOG		0x8001910C

// Define special function registers for GPIO Bank 1 (Gyro input: pin 19)
#define HW_PINCTRL_MUXSEL3	0x80018130
#define HW_PINCTRL_MUXSEL3_SET	0x80018134
#define HW_PINCTRL_MUXSEL3_CLR	0x80018138
#define HW_PINCTRL_MUXSEL3_TOG	0x8001813C

#define HW_PINCTRL_PULL1_SET	0x80018614 // For setting pull up resistors

#define HW_PINCTRL_DOUT1_SET	0x80018714 // Data ouput registers
#define HW_PINCTRL_DOUT1_CLR	0x80018718
#define HW_PINCTRL_DOUT1_TOG	0x8001871C

#define HW_PINCTRL_DOE1_SET	0x80018B14 // Data ouput enable registers
#define HW_PINCTRL_DOE1_CLR	0x80018B18

#define HW_PINCTRL_IRQLEVEL1		0x80019210 // Interrupt level/edge registers
#define HW_PINCTRL_IRQLEVEL1_SET	0x80019214
#define HW_PINCTRL_IRQLEVEL1_CLR	0x80019218
#define HW_PINCTRL_IRQLEVEL1_TOG	0x8001921C

#define HW_PINCTRL_IRQPOL1		0x80019310 // Interrupt polarity registers
#define HW_PINCTRL_IRQPOL1_SET		0x80019314
#define HW_PINCTRL_IRQPOL1_CLR		0x80019318
#define HW_PINCTRL_IRQPOL1_TOG		0x8001931C

#define HW_PINCTRL_IRQSTAT1		0x80019410 // Interrupt status registers
#define HW_PINCTRL_IRQSTAT1_SET		0x80019414
#define HW_PINCTRL_IRQSTAT1_CLR		0x80019418
#define HW_PINCTRL_IRQSTAT1_TOG		0x8001941C

#define HW_PINCTRL_PIN2IRQ1		0x80019010 // Interrupt select registers
#define HW_PINCTRL_PIN2IRQ1_SET		0x80019014
#define HW_PINCTRL_PIN2IRQ1_CLR		0x80019018
#define HW_PINCTRL_PIN2IRQ1_TOG		0x8001901C

#define HW_PINCTRL_IRQEN1		0x80019110 // Interrupt mask registers
#define HW_PINCTRL_IRQEN1_SET		0x80019114
#define HW_PINCTRL_IRQEN1_CLR		0x80019118
#define HW_PINCTRL_IRQEN1_TOG		0x8001911C

// Define special function registers for GPIO Bank 2 (Inclio input: pin 19)
#define HW_PINCTRL_MUXSEL5	0x80018150
#define HW_PINCTRL_MUXSEL5_SET	0x80018154
#define HW_PINCTRL_MUXSEL5_CLR	0x80018158
#define HW_PINCTRL_MUXSEL5_TOG	0x8001815C

#define HW_PINCTRL_PULL2_SET	0x80018624 // For setting pull up resistors

#define HW_PINCTRL_DOUT2_SET	0x80018724 // Data ouput registers
#define HW_PINCTRL_DOUT2_CLR	0x80018728
#define HW_PINCTRL_DOUT2_TOG	0x8001872C

#define HW_PINCTRL_DOE2_SET	0x80018B24 // Data ouput enable registers
#define HW_PINCTRL_DOE2_CLR	0x80018B28

#define HW_PINCTRL_IRQLEVEL2		0x80019220 // Interrupt level/edge registers
#define HW_PINCTRL_IRQLEVEL2_SET	0x80019224
#define HW_PINCTRL_IRQLEVEL2_CLR	0x80019228
#define HW_PINCTRL_IRQLEVEL2_TOG	0x8001922C

#define HW_PINCTRL_IRQPOL2		0x80019320 // Interrupt polarity registers
#define HW_PINCTRL_IRQPOL2_SET		0x80019324
#define HW_PINCTRL_IRQPOL2_CLR		0x80019328
#define HW_PINCTRL_IRQPOL2_TOG		0x8001932C

#define HW_PINCTRL_IRQSTAT2		0x80019420 // Interrupt status registers
#define HW_PINCTRL_IRQSTAT2_SET		0x80019424
#define HW_PINCTRL_IRQSTAT2_CLR		0x80019428
#define HW_PINCTRL_IRQSTAT2_TOG		0x8001942C

#define HW_PINCTRL_PIN2IRQ2		0x80019020 // Interrupt select registers
#define HW_PINCTRL_PIN2IRQ2_SET		0x80019024
#define HW_PINCTRL_PIN2IRQ2_CLR		0x80019028
#define HW_PINCTRL_PIN2IRQ2_TOG		0x8001902C

#define HW_PINCTRL_IRQEN2		0x80019120 // Interrupt mask registers
#define HW_PINCTRL_IRQEN2_SET		0x80019124
#define HW_PINCTRL_IRQEN2_CLR		0x80019128
#define HW_PINCTRL_IRQEN2_TOG		0x8001912C

// Define special function registers for GPIO Bank 3 (Inclio input: PWM3 used as GPIO pin for Timer input - Pin_3_21)
#define HW_PINCTRL_MUXSEL7	0x80018170
#define HW_PINCTRL_MUXSEL7_SET	0x80018174
#define HW_PINCTRL_MUXSEL7_CLR	0x80018178
#define HW_PINCTRL_MUXSEL7_TOG	0x8001817C

#define HW_PINCTRL_PULL3_SET	0x80018634 // For setting pull up resistors

#define HW_PINCTRL_DOUT3_SET	0x80018734 // Data ouput registers
#define HW_PINCTRL_DOUT3_CLR	0x80018738
#define HW_PINCTRL_DOUT3_TOG	0x8001873C

#define HW_PINCTRL_DOE3_SET	0x80018B34 // Data ouput enable registers
#define HW_PINCTRL_DOE3_CLR	0x80018B38

#define HW_PINCTRL_IRQLEVEL3		0x80019230 // Interrupt level/edge registers
#define HW_PINCTRL_IRQLEVEL3_SET	0x80019234
#define HW_PINCTRL_IRQLEVEL3_CLR	0x80019238
#define HW_PINCTRL_IRQLEVEL3_TOG	0x8001923C

#define HW_PINCTRL_IRQPOL3		0x80019330 // Interrupt polarity registers
#define HW_PINCTRL_IRQPOL3_SET		0x80019334
#define HW_PINCTRL_IRQPOL3_CLR		0x80019338
#define HW_PINCTRL_IRQPOL3_TOG		0x8001933C

#define HW_PINCTRL_IRQSTAT3		0x80019430 // Interrupt status registers
#define HW_PINCTRL_IRQSTAT3_SET		0x80019434
#define HW_PINCTRL_IRQSTAT3_CLR		0x80019438
#define HW_PINCTRL_IRQSTAT3_TOG		0x8001943C

#define HW_PINCTRL_PIN2IRQ3		0x80019030 // Interrupt select registers
#define HW_PINCTRL_PIN2IRQ3_SET		0x80019034
#define HW_PINCTRL_PIN2IRQ3_CLR		0x80019038
#define HW_PINCTRL_PIN2IRQ3_TOG		0x8001903C

#define HW_PINCTRL_IRQEN3		0x80019130 // Interrupt mask registers
#define HW_PINCTRL_IRQEN3_SET		0x80019134
#define HW_PINCTRL_IRQEN3_CLR		0x80019138
#define HW_PINCTRL_IRQEN3_TOG		0x8001913C

// Define special function registers for PWM modules (PWM3: encoder input, PWM4: motor left, PWM5: motor right, PWM6: servo 1, PWM7: servo 2)
#define HW_PWM_CTRL		0x80064000
#define HW_PWM_CTRL_SET		0x80064004
#define HW_PWM_CTRL_CLR		0x80064008
#define HW_PWM_CTRL_TOGGLE	0x8006400C

#define HW_PWM_ACTIVE3		0x80064070
#define HW_PWM_ACTIVE3_SET	0x80064074
#define HW_PWM_ACTIVE3_CLR	0x80064078
#define HW_PWM_ACTIVE3_TOGGLE	0x8006407C

#define HW_PWM_PERIOD3		0x80064080
#define HW_PWM_PERIOD3_SET	0x80064084
#define HW_PWM_PERIOD3_CLR	0x80064088
#define HW_PWM_PERIOD3_TOGGLE	0x8006408C

#define HW_PWM_ACTIVE4		0x80064090
#define HW_PWM_ACTIVE4_SET	0x80064094
#define HW_PWM_ACTIVE4_CLR	0x80064098
#define HW_PWM_ACTIVE4_TOGGLE	0x8006409C

#define HW_PWM_PERIOD4		0x800640A0
#define HW_PWM_PERIOD4_SET	0x800640A4
#define HW_PWM_PERIOD4_CLR	0x800640A8
#define HW_PWM_PERIOD4_TOGGLE	0x800640AC

#define HW_PWM_ACTIVE5		0x800640B0
#define HW_PWM_ACTIVE5_SET	0x800640B4
#define HW_PWM_ACTIVE5_CLR	0x800640B8
#define HW_PWM_ACTIVE5_TOGGLE	0x800640BC

#define HW_PWM_PERIOD5		0x800640C0
#define HW_PWM_PERIOD5_SET	0x800640C4
#define HW_PWM_PERIOD5_CLR	0x800640C8
#define HW_PWM_PERIOD5_TOGGLE	0x800640CC

#define HW_PWM_ACTIVE6		0x800640D0
#define HW_PWM_ACTIVE6_SET	0x800640D4
#define HW_PWM_ACTIVE6_CLR	0x800640D8
#define HW_PWM_ACTIVE6_TOGGLE	0x800640DC

#define HW_PWM_PERIOD6		0x800640E0
#define HW_PWM_PERIOD6_SET	0x800640E4
#define HW_PWM_PERIOD6_CLR	0x800640E8
#define HW_PWM_PERIOD6_TOGGLE	0x800640EC

#define HW_PWM_ACTIVE7		0x800640F0
#define HW_PWM_ACTIVE7_SET	0x800640F4
#define HW_PWM_ACTIVE7_CLR	0x800640F8
#define HW_PWM_ACTIVE7_TOGGLE	0x800640FC

#define HW_PWM_PERIOD7		0x80064100
#define HW_PWM_PERIOD7_SET	0x80064104
#define HW_PWM_PERIOD7_CLR	0x80064108
#define HW_PWM_PERIOD7_TOGGLE	0x8006410C

#define HW_PINCTRL_DRIVE14_SET	0x800183E4
#define HW_PINCTRL_DRIVE15_SET	0x800183F4


// Define special function registers for interrupt collector
#define HW_ICOLL_VECTOR		0x80000000
#define HW_ICOLL_VECTOR_SET	0x80000004
#define HW_ICOLL_VECTOR_CLR	0x80000008
#define HW_ICOLL_VECTOR_TOG	0x8000000C

#define HW_ICOLL_LEVELACK       0x80000010

#define HW_ICOLL_CTRL		0x80000020
#define HW_ICOLL_CTRL_SET	0x80000024
#define HW_ICOLL_CTRL_CLR	0x80000028
#define HW_ICOLL_CTRL_TOG	0x8000002C

#define HW_ICOLL_VBASE		0x80000040
#define HW_ICOLL_VBASE_SET	0x80000044
#define HW_ICOLL_VBASE_CLR	0x80000048
#define HW_ICOLL_VBASE_TOG	0x8000004C

#define HW_ICOLL_INTERRUPT0	0x80000120
#define HW_ICOLL_INTERRUPT0_SET	0x80000124
#define HW_ICOLL_INTERRUPT0_CLR	0x80000128
#define HW_ICOLL_INTERRUPT0_TOG	0x8000012C

// Define special function register for peripherals
// Timer 0
#define HW_TIMROT_ROTCTRL	0x80068000
#define HW_TIMROT_ROTCTRL_SET	0x80068004
#define HW_TIMROT_ROTCTRL_CLR	0x80068008
#define HW_TIMROT_ROTCTRL_TOG	0x8006800C

#define HW_TIMROT_TIMCTRL0	0x80068020
#define HW_TIMROT_TIMCTRL0_SET	0x80068024
#define HW_TIMROT_TIMCTRL0_CLR	0x80068028
#define HW_TIMROT_TIMCTRL0_TOG	0x8006802C

#define HW_TIMROT_FIXED_COUNT0	0x80068040
#define HW_TIMROT_RUNNING_COUNT0 0x80068030
// Timer 1
#define HW_TIMROT_TIMCTRL1	0x80068060
#define HW_TIMROT_TIMCTRL1_SET	0x80068064
#define HW_TIMROT_TIMCTRL1_CLR	0x80068068
#define HW_TIMROT_TIMCTRL1_TOG	0x8006806C

#define HW_TIMROT_FIXED_COUNT1	0x80068080
#define HW_TIMROT_RUNNING_COUNT1 0x80068070
// Timer 2
#define HW_TIMROT_TIMCTRL2	0x800680A0
#define HW_TIMROT_TIMCTRL2_SET	0x800680A4
#define HW_TIMROT_TIMCTRL2_CLR	0x800680A8
#define HW_TIMROT_TIMCTRL2_TOG	0x800680AC

#define HW_TIMROT_FIXED_COUNT2	0x800680C0
#define HW_TIMROT_RUNNING_COUNT2 0x800680B0
// Timer 3
#define HW_TIMROT_TIMCTRL3	0x800680E0
#define HW_TIMROT_TIMCTRL3_SET	0x800680E4
#define HW_TIMROT_TIMCTRL3_CLR	0x800680E8
#define HW_TIMROT_TIMCTRL3_TOG	0x800680EC

#define HW_TIMROT_FIXED_COUNT3	0x80068100
#define HW_TIMROT_MATCH_COUNT3	0x80068110
#define HW_TIMROT_RUNNING_COUNT3 0x800680F0
// Debug UART
// MUX control registers for pins of Debug UART
#define HW_PINCTRL_MUXSEL7      0x80018170
#define HW_PINCTRL_MUXSEL7_SET  0x80018174
#define HW_PINCTRL_MUXSEL7_CLR  0x80018178
#define HW_PINCTRL_MUXSEL7_TOG  0x8001817C

#define UART1_BASE_ADDR         0x80074000

// Clock 
#define CLKCTRL_ADDR            0x80040000
#define CLKCTRL_XTAL_ADDR       (CLKCTRL_ADDR + 0x80)
#define CLKCTRL_XTAL_CLR_ADDR   (CLKCTRL_XTAL_ADDR + 0x8)

#define HW_CLKCTRL_XTAL		0x80040080
#define HW_CLKCTRL_XTAL_SET	0x80040084
#define HW_CLKCTRL_XTAL_CLR	0x80040088
#define HW_CLKCTRL_XTAL_TOG	0x8004008C


/***************************************************************************
 **
 **   MCIX28 interrupt sources
 **
 ***************************************************************************/
#define INT_BATT_BROWNOUT       0             /* Power module battery brownout detect */
#define INT_VDDD_BROWNOUT       1             /* Power module VDDD brownout detect */
#define INT_VDDIO_BROWNOU       2             /* Power module VDDIO brownout detect */
#define INT_VDDA_BROWNOUT       3             /* Power module VDDA brownout detect */
#define INT_VDD5V_DROOP         4             /* 5V Droop */
#define INT_DCDC4P2_BROWNOUT    5             /* 4.2V regulated supply brown-out */
#define INT_VDD5V               6             /* 5V connect or disconnect also OTG 4.2V */
#define INT_CAN0                8             /* CAN 0 */
#define INT_CAN1                9             /* CAN 1 */
#define INT_LRADC_TOUCH        10             /* (Touch Screen Touch detection */
#define INT_HSADC              13             /* HSADC */
#define INT_LRADC_THRESH0      14             /* LRADC0 Threshold */
#define INT_LRADC_THRESH1      15             /* LRADC1 Threshold */
#define INT_LRADC_CH0          16             /* LRADC Channel 0 conversion complete */
#define INT_LRADC_CH1          17             /* LRADC Channel 1 conversion complete */
#define INT_LRADC_CH2          18             /* LRADC Channel 2 conversion complete */
#define INT_LRADC_CH3          19             /* LRADC Channel 3 conversion complete */
#define INT_LRADC_CH4          20             /* LRADC Channel 4 conversion complete */
#define INT_LRADC_CH5          21             /* LRADC Channel 5 conversion complete */
#define INT_LRADC_CH6          22             /* LRADC Channel 6 conversion complete */
#define INT_LRADC_CH7          23             /* LRADC Channel 7 conversion complete */
#define INT_LRADC_BUTTON0      24             /* LRADC Channel 0 button detection */
#define INT_LRADC_BUTTON1      25             /* LRADC Channel 1 button detection */
#define INT_PERFMON            27             /* Performance monitor */
#define INT_RTC_1MSEC          28             /* RTC 1ms event */
#define INT_RTC_ALARM          29             /* RTC alarm event */
#define INT_COMMS              31             /* JTAG debug communications port */
#define INT_EMI_ERROR          32             /* External memory controller */
#define INT_LCDIF              38             /* LCDIF */
#define INT_PXP                39             /* PXP */
#define INT_BCH                41             /* BCH consolidated */
#define INT_GPMI               42             /* GPMI internal error and status */
#define INT_SPDIF_ERROR        45             /* SPDIF FIFO error */
#define INT_DUART              47             /* Debug UART */
#define INT_TIMER0             48             /* Timer 0 */
#define INT_TIMER1             49             /* Timer 1 */
#define INT_TIMER2             50             /* Timer 2 */
#define INT_TIMER3             51             /* Timer 3 */
#define INT_DCP_VMI            52             /* DCP Channel 0 virtual memory page copy */
#define INT_DCP                53             /* DCP (per channel and CSC */
#define INT_DCP_SECURE         54             /* DCP secure */
#define INT_SAIF1              58             /* SAIF1 FIFO & Service error */
#define INT_SAIF0              59             /* SAIF0 FIFO & Service error */
#define INT_SPDIF_DMA          66             /* SPDIF DMA channel */
#define INT_I2C0_DMA           68             /* I2C0 DMA channel */
#define INT_I2C1_DMA           69             /* I2C1 DMA channel */
#define INT_AUART0_RX_DMA      70             /* Application UART0 receiver DMA channel */
#define INT_AUART0_TX_DMA      71             /* Application UART0 transmitter DMA channel */
#define INT_AUART1_RX_DMA      72             /* Application UART1 receiver DMA channel */
#define INT_AUART1_TX_DMA      73             /* Application UART1 transmitter DMA channel */
#define INT_AUART2_RX_DMA      74             /* Application UART2 receiver DMA channel */
#define INT_AUART2_TX_DMA      75             /* Application UART2 transmitter DMA channel */
#define INT_AUART3_RX_DMA      76             /* Application UART3 receiver DMA channel */
#define INT_AUART3_TX_DMA      77             /* Application UART3 transmitter DMA channel */
#define INT_AUART4_RX_DMA      78             /* Application UART4 receiver DMA channel */
#define INT_AUART4_TX_DMA      79             /* Application UART4 transmitter DMA channel */
#define INT_SAIF0_DMA          80             /* SAIF0 DMA channel */
#define INT_SAIF1_DMA          81             /* SAIF1 DMA channel */
#define INT_SSP0_DMA           82             /* SSP0 DMA channel */
#define INT_SSP1_DMA           83             /* SSP1 DMA channel */
#define INT_SSP2_DMA           84             /* SSP2 DMA channel */
#define INT_SSP3_DMA           85             /* SSP3 DMA channel */
#define INT_LCDIF_DMA          86             /* LCDIF DMA channel */
#define INT_HSADC_DMA          87             /* HSADC DMA channel */
#define INT_GPMI_DMA           88             /* GPMI DMA channel */
#define INT_DIGCTL_DEBUG_TRAP  89             /* Layer 0 or Layer 3 AHB address access trap */
#define INT_USB1               92             /* USB1 */
#define INT_USB0               93             /* USB0 */
#define INT_USB1_WAKEUP        94             /* UTM1 */
#define INT_USB0_WAKEUP        95             /* UTM0 */
#define INT_SSP0_ERROR         96             /* SSP0 device-level error and status */
#define INT_SSP1_ERROR         97             /* SSP1 device-level error and status */
#define INT_SSP2_ERROR         98             /* SSP2 device-level error and status */
#define INT_SSP3_ERROR         99             /* SSP3 device-level error and status */
#define INT_ENET_SWI          100             /* Switch */
#define INT_ENET_MAC0         101             /* MAC0 */
#define INT_ENET_MAC1         102             /* MAC1 */
#define INT_ENET_MAC0_1588    103             /* 1588 of MAC0 */
#define INT_ENET_MAC1_1588    104             /* 1588 of MAC1 */
#define INT_I2C1_ERROR        110             /* I2C1 device detected errors and line conditions */
#define INT_I2C0_ERROR        111             /* I2C0 device detected errors and line conditions */
#define INT_AUART0            112             /* Application UART0 internal error */
#define INT_AUART1            113             /* Application UART1 internal error */
#define INT_AUART2            114             /* Application UART2 internal error */
#define INT_AUART3            115             /* Application UART3 internal error */
#define INT_AUART4            116             /* Application UART4 internal error */
#define INT_PINCTRL5          122             /* GPIO bank 5 interrupt */
#define INT_PINCTRL4          123             /* GPIO bank 4 interrupt */
#define INT_PINCTRL3          124             /* GPIO bank 3 interrupt */
#define INT_PINCTRL2          125             /* GPIO bank 2 interrupt */
#define INT_PINCTRL1          126             /* GPIO bank 1 interrupt */
#define INT_PINCTRL0          127             /* GPIO bank 0 interrupt */
 
#endif // __IMX286_REGS_H
