/*
*********************************************************************************************************
*                                               Freescale i.MX286
*
*                                
* File : BSP.H
* By   : Pham Van Thuan
*********************************************************************************************************
*/
#ifndef __BSP_H
#define __BSP_H

#include "arm_types.h"

/*
*********************************************************************************************************
*                                           DEFINES
*********************************************************************************************************
*/
#define TIMER_CLOCK_FREQ 24000000

#define led_mask 	1<<21   // User Led Bank 0 Pin 21
#define button_mask	1<<17	// User Button Bank 0 Pin 17

#define LED_ON()	(writel(led_mask, HW_PINCTRL_DOUT0_SET))
#define LED_OFF() 	(writel(led_mask, HW_PINCTRL_DOUT0_CLR))
#define LED_TOGGLE() 	(writel(led_mask, HW_PINCTRL_DOUT0_TOG))

typedef void(*IntrFunc_t)(void);

typedef enum
{
  LEVEL0 = 0,
  LEVEL1,
  LEVEL2,
  LEVEL3
} ICOLL_priority_t;

/*
*********************************************************************************************************
*                                            BSP FUNCTION PROTOTYPES
*********************************************************************************************************
*/

void        BSP_Init(void);
void        LED_Init(void);
void        Tmr_TickInit(void);
void        Tmr_TickISR_Handler(void);
void 	    BSP_IntDisAll(void); 
void        BSP_IntEnaAll(void);

void 	    Encoder_Init(void);
void 	    Encoder2_Init(void);
void	    Motor_Init(void);

/*
*********************************************************************************************************
*                                        INTERRUPT COLLECTOR FUNCTIONS
*********************************************************************************************************
*/

void ICOLL_Init(void); // Initialize ICOLL
void ICOLL_SetupIntr(IntrFunc_t pIntrSub, Boolean FastIntr, Int32U IntrSource, ICOLL_priority_t Priority); // Set up interrupt service routine
void ICOLL_EnableIntr(Int32U IntrSource); // Enable a interrupt source
void ICOLL_DisableIntr(Int32U IntrSource); // Disable a interrupt source

#endif // BSP
