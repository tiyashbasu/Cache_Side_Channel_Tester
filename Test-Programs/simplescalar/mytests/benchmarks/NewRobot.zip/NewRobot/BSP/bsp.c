/*
*********************************************************************************************************
*                                           Freescale i.MX286
* File : BSP.C
* By   : Pham Van Thuan
*********************************************************************************************************
*/

#include <includes.h>

/* Structure for each interrupt source */

typedef struct _VectorEntry_t
{
	IntrFunc_t 	Callback; /* Pointer to interrupt service routine */
	Int32U 		PtiorityLevel; /* Priority of the interrupt source */
} VectorEntry_t, * pVectorEntry_t;

/* Assembly code for enable/disable interrupt by clear/set I-bit */

__attribute__( ( always_inline ) ) void __enable_irq(void)
{
  __asm ("mrs	r0, cpsr"); 
  __asm ("bic r0, r0, #0x80"); //enable interrupt 
  __asm ("msr	cpsr_c, r0");    	
}

__attribute__( ( always_inline ) ) void __disable_irq(void)
{
  __asm ("mrs	r0, cpsr"); 
  __asm ("orr	r0, r0, #0x80"); //disable interrupt
  __asm ("msr	cpsr_c, r0");    
}

__attribute__( ( always_inline ) ) void __configure_MMU(void)
{
	register Int32U val asm("r0"); 
	//Step 1: Update TTB register to point to address of first level page tables (0x00004000)
	val=0x00004000;
	__asm ("mcr	p15, 0, r0, c2, c0, 0"); //update Translation Table Base Register C2
	//Step 2: configure domain access control register (domain 0 in manager mode)
	val=0x00000003;
	__asm ("mcr	p15, 0, r0, c3, c0, 0");
	//Step 3: program first level page entries (3 sections: 1 for SRAM 0x00000000, 1 for SDRAM 0x40000000, 1 for PIO 0x80000000)
	//Section 1: 0x00000C12 (AP=11, DOMAIN=0, CB=10 (write-through cacheable)
	//Section 2: 0x40000C12 (AP=11, DOMAIN=0, CB=10 (write-through cacheable)
	//Section 3: 0x80000C12 (AP=11, DOMAIN=0, C=0 (uncached), B=0 (unbuffered)
	writel(0x00000C1A, 0x00004000); //section 0
	writel(0x40000C1A, 0x00005000); //section 1024
	writel(0x80000C12, 0x00006000); //section 2048
	//Lock three sections to TLB lockdown
	//Invalidate alll entries in the TLB
	val=0x0;
	__asm ("mcr	p15, 0, r0, c8, c7, 0");
	//Modify the preserve bit of the lockdown register
	__asm ("mrc	p15, 0, r0, c10, c0, 0");
	__asm ("orr     r0, r0, #1"); //set presevrve bit
	__asm ("mcr	p15, 0, r0, c10, c0, 0");
	//Access section 1
	readl(0x00000000);
	//Access section 2
	readl(0x40000000);
	//Access section 3
	readl(0x80000000);
	//clear preserve bit
	__asm ("mrc	p15, 0, r0, c10, c0, 0");
	__asm ("bic     r0, r0, #1"); //clear preserve bit
	//Update the lockdown register
	__asm ("mcr	p15, 0, r0, c10, c0, 0");
}

__attribute__( ( always_inline ) ) void __enable_cache(void)
{  
  register Int32U val asm("r0");  
  __asm ("mrc	p15, 0, r0, c1, c0, 0"); //read current 
  __asm ( //test clean and invalidate cache
	"tci_loop: mrc p15, 0, r15, c7, c14, 3\n\t"
	"bne tci_loop"
  );
  val |= 1UL<<0 | 1UL<<2 | 1UL<<12 | 1UL<<14; //enable I cache and D cache, enable MMU, Round-robin replacement policy
  //val |= 1UL<<12 | 1UL<<14; //enable I cache, disable D cache and MMU, Round-robin replacement policy
  //val |= 1UL<<2 | 1UL<<12; //enable I cache and D cache, disable MMU
  __asm ("mcr	p15, 0, r0, c1, c0, 0"); //update cache state
  /* configure Cache Debug Control Register to force Write-Through behavior */
  __asm ("mrc	p15, 7, r0, c15, c0, 0"); //read Cache Debug Control Register
  val |= 1UL<<2; //Force Write-Through behavior
  __asm ("mcr	p15, 7, r0, c15, c0, 0"); //update Cache Debug Control Register 
  
}
__attribute__( ( always_inline ) ) void __disable_cache(void)
{
  register Int32U val asm("r0");  
  __asm ("mrc	p15, 0, r0, c1, c0, 0"); //read current 
  val &= ~1UL<<2; //disable D cache
  __asm ("mcr	p15, 0, r0, c1, c0, 0"); //update cache state
}

__attribute__( ( always_inline ) ) void __disable_noncacheable_intruction_fetch(void)
{
  register Int32U val asm("r0");  
  /* configure Debug Override Register */
  __asm ("mrc	p15, 0, r0, c15, c0, 0"); //read Debug Override Register
  val |= 1UL<<16; //Disable prefetching
  __asm ("mcr	p15, 0, r0, c15, c0, 0"); //update Debug Override Register  
}

/*
*********************************************************************************************************
*                                              VARIABLES
*********************************************************************************************************
*/

static VectorEntry_t VectorTable[128];
static IntrFunc_t FastIsr;

/*
*********************************************************************************************************
*                                         BSP INITIALIZATION
*
* Description : This function should be called by your application code before you make use of any of the
*               functions found in this module.
*
* Arguments   : none
*********************************************************************************************************
*/

void  BSP_Init (void)
{    
    //__configure_MMU();
    __enable_cache();
    __disable_noncacheable_intruction_fetch();    
    init_debug_uart(115200);						/* Initialize the Debug UART 				    */    
    ICOLL_Init();                                                       /* Initialize the Vectored Interrupt Controller             */
    LED_Init();                                                         /* Initialize the I/Os for the LED controls                 */        
    
    Tmr_TickInit();    							/* Initialize the uC/OS-II tick interrupt                   */      
    Tmr_1MHzInit();  
    IRTV_Init();                                                 
   
    __enable_irq();       
}


void BSP_IntDisAll(void)
{
    __disable_irq();	
}

void BSP_IntEnaAll(void)
{
    __enable_irq();	
}

/*
*********************************************************************************************************
*                                         BSP INITIALIZATION
*
* Description : This function should be called by your application code before you make use of any of the
*               functions found in this module.
*
* Arguments   : none
*********************************************************************************************************
*/

void  LED_Init (void)
{
  /* Initialize PIO for Led */

  // Set the HW_PINCTRL_CTRL
  writel(0x0, HW_PINCTRL_CTRL);
  // Set HW_PINCTRL_MUXSELx (set bit 10 and 11)
  writel(0x00000C00, HW_PINCTRL_MUXSEL1_SET);
  // Set the HW_PINCTRL_DRIVEx (3.3V, 8mA)
  writel(0x00000050, HW_PINCTRL_DRIVE2_SET);
  // Set the HW_PINCTRL_PULLx (no pull up resister)
  writel(led_mask, HW_PINCTRL_PULL0_SET);
  // Enable ouput
  writel(led_mask, HW_PINCTRL_DOE0_SET);
  // LED OFF
  writel(led_mask, HW_PINCTRL_DOUT0_CLR); 

  /* Turn off the led */  
  LED_OFF();
}

// Clock for generating timer tick (Timer 0)
void  Tmr_TickInit(void)
{
  volatile int i;
  /* Init TIMROT T0*/
  /* Reset TIMROT module*/
  writel(1<<31, HW_TIMROT_ROTCTRL_SET); //SFTRST = 1;
  for(i = 100; i; i--);
  writel(1<<31, HW_TIMROT_ROTCTRL_CLR); //SFTRST = 0;
  /* Enable clock*/
  for(i = 100; i; i--);
  writel(1<<30, HW_TIMROT_ROTCTRL_CLR); //CLKGATE = 0;

  writel((1<<4) | (1<<5), HW_TIMROT_TIMCTRL0_CLR); //PRESCALE = 0;
  writel(1<<6, HW_TIMROT_TIMCTRL0_SET);	//RELOAD = 1;
  writel(1<<7, HW_TIMROT_TIMCTRL0_CLR);	//UPDATE = 0;
  writel(1<<14, HW_TIMROT_TIMCTRL0_SET); //IRQ_EN = 1;
  writel(TIMER_CLOCK_FREQ / OS_TICKS_PER_SEC , HW_TIMROT_FIXED_COUNT0);

  /*Setup Timer 0 interrupt*/
  ICOLL_SetupIntr(Tmr_TickISR_Handler, 0, INT_TIMER0, LEVEL3);
  /*Enable Interrupt in ICOLL*/
  ICOLL_EnableIntr(INT_TIMER0);
  /*Start timer. Clock from 24MHz*/
  writel(0x0F, HW_TIMROT_TIMCTRL0_SET); //SELECT = 0xF;      
}

/*
*********************************************************************************************************
*                                         TIMER #0 IRQ HANDLER
*
* Description : This function handles the timer interrupt that is used to generate TICKs for uC/OS-II.
*
* Arguments   : none
*********************************************************************************************************
*/

void  Tmr_TickISR_Handler (void)
{    
#if (TASK_TO_MEASURE == 4)
	START_MEASURE();
#endif
    // Clear interrupt flag
    writel(1<<15, HW_TIMROT_TIMCTRL0_CLR);
    // Toggle the led to indicate interrupt occur 
    //LED_TOGGLE(); 
    // Call uC/OS-II's OSTimeTick 
    OSTimeTick();
#if (TASK_TO_MEASURE == 4)
	END_MEASURE();
#endif
}

/*************************************************************************
 * Function Name: ICOLL_Init
 * Parameters: none
 *
 * Return: none
 *
 * Description: Init Interrupt controller
 *
 *************************************************************************/
void ICOLL_Init(void)
{
  volatile int i;  
  __disable_irq();
  /*Soft reset*/  
  writel(1<<31, HW_ICOLL_CTRL_SET); //SFTRST = 1;
  for(i = 100; i; i--);
  writel(1<<31, HW_ICOLL_CTRL_CLR); //SFTRST = 0;
  /*Enable interrupt collector*/
  for(i = 100; i; i--);
  writel(1<<30, HW_ICOLL_CTRL_CLR);   //CLKGATE = 0;
  /*Init Interrupt collector*/
  writel(1<<18, HW_ICOLL_CTRL_SET);		/* ARM_RSE_MODE = 1;   ARM-style, interrupt inservice is
                                          	 signalled by the read of the
                                          	 HW_ICOLL_VECTOR register to acquire
                                          	 the interrupt vector address */
  writel(1<<19, HW_ICOLL_CTRL_SET);	     	/* NO_NESTING=1; Disable nested interrupts */
  writel(1<<22, HW_ICOLL_CTRL_SET);  		/* VECTOR_PITCH = 2;  	two word pitch */
  writel((1<<21) | (1<<23), HW_ICOLL_CTRL_CLR);

  writel((Int32U) VectorTable, HW_ICOLL_VBASE);	/* Set vector table base address */

  writel(1<<17, HW_ICOLL_CTRL_SET);		/* FIQ_FINAL_ENABLE = 1; enable the final FIQ output */
  writel(1<<16, HW_ICOLL_CTRL_SET);		/* IRQ_FINAL_ENABLE = 1; enable the final IRQ output */  
  //__enable_irq();
}

/*************************************************************************
 * Function Name: ICOLL_SetupIntr
 * Parameters: IntrFunc_t pIntrSub - pointer to the interrupt service routine
 *             Boolean FastIntr    - 0 -IRQ : 1- FIQ
 *             Int32U IntrSouce     - Interrupt intedx (0 - 127)
 *             ICOLL_priority_t Priority  - priority level
 *
 * Return: none
 *
 * Description: Setup the interrupt priority, type and service routine.
 *              The interrupt will be disabled.
 *************************************************************************/
void ICOLL_SetupIntr(IntrFunc_t pIntrSub, Boolean FastIntr,
                    Int32U IntrSource, ICOLL_priority_t Priority)
{
Int32U * Interrupt = ((Int32U *)HW_ICOLL_INTERRUPT0) + 4*IntrSource;
pVectorEntry_t entry;

  /*Sanitary check*/
  if(IntrSource > 127)
  {
    return;
  }

  /*If not fast interrupt*/
  if(!FastIntr)
  {
    entry = VectorTable + IntrSource;
    /*updated interrupt register. This will disable the corresponding interrupt*/
    *Interrupt = Priority;
    /*Set ISR*/
    entry->Callback = pIntrSub;
    entry->PtiorityLevel = 1ul<<Priority;
  }
  else
  {
    /*updated interrupt register. This will disable the corresponding interrupt*/
    *Interrupt = 1<<4;
    /*Set ISR*/
    FastIsr = pIntrSub;
  }
}

/*************************************************************************
 * Function Name: ICOLL_EnableIntr
 * Parameters: Int32U IntrSource - Interrupt intedx (0 - 127)
 *
 * Return: none
 *
 * Description: Enable Interrupt
 *
 *************************************************************************/
void ICOLL_EnableIntr(Int32U IntrSource)
{
Int32U * Interrupt = ((Int32U *)HW_ICOLL_INTERRUPT0_SET) + 4*IntrSource;

  /*Sanitary check*/
  if(IntrSource > 127)
  {
    return;
  }

  *Interrupt = 1<<2;
}

/*************************************************************************
 * Function Name: ICOLL_DisableIntr
 * Parameters: Int32U IntrSource - Interrupt intedx (0 - 127)
 *
 * Return: none
 *
 * Description: Disable Interrupt
 *
 *************************************************************************/
void ICOLL_DisableIntr(Int32U IntrSource)
{
Int32U * Interrupt = ((Int32U *)HW_ICOLL_INTERRUPT0_CLR) + 4*IntrSource;

  /*Sanitary check*/
  if(IntrSource > 127)
  {
    return;
  }

  *Interrupt = 1<<2;
}


/*
*********************************************************************************************************
*                                          EXCEPTION HANDLER
*
* Description : This function should be used to handle any exceptions.  It is called by
*               OS_CPU_ARM_ExceptHndlr(), which is declared in os_cpu_a.asm
*
* Arguments   : ID, an identifier used to indicate what type of ARM exception has been triggered
*               Possible ID values are shown below.
*                  OS_CPU_ARM_EXCEPT_RESET             0x00
*                  OS_CPU_ARM_EXCEPT_UNDEF_INSTR       0x01
*                  OS_CPU_ARM_EXCEPT_SWI               0x02
*                  OS_CPU_ARM_EXCEPT_PREFETCH_ABORT    0x03
*                  OS_CPU_ARM_EXCEPT_DATA_ABORT        0x04
*                  OS_CPU_ARM_EXCEPT_ADDR_ABORT        0x05
*                  OS_CPU_ARM_EXCEPT_IRQ               0x06
*                  OS_CPU_ARM_EXCEPT_FIQ               0x07
*
* Notes       : The ISR handler being called MUST clear the AIC by clearing any external sources and
*               then writting the AIC ICCR and EOICR registers.
*********************************************************************************************************
*/

void  OS_CPU_ExceptHndlr (Int32U  except_id)
{
    Int32U    *sp;
    if (except_id == OS_CPU_ARM_EXCEPT_FIQ) {
       (FastIsr)();    /*Call installed interrupt service routine*/
    } else if (except_id == OS_CPU_ARM_EXCEPT_IRQ) {
         VectorEntry_t * entry = (VectorEntry_t *)(*(volatile unsigned int *)HW_ICOLL_VECTOR);
  	__enable_irq();

  	(*entry->Callback)();  	/*Call installed interrupt service routine*/

  	__disable_irq();

  	writel(entry->PtiorityLevel, HW_ICOLL_LEVELACK);	/*Priority Level Restore*/
    } else {
	// Other CPU ARM EXCEPTION
        sp = (Int32U *)OSTCBCur->OSTCBStkPtr;
        // Infinite loop on other exceptions.                                                                      
        while (1) {
            ;
        }
    }
}










