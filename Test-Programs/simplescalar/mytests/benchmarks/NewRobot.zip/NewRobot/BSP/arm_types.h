#ifndef __ARM_TYPES_H
#define __ARM_TYPES_H

#ifndef NULL
#define NULL	(void*)0x00
#endif

#ifndef TRUE
#define TRUE	1
#define FALSE	0
#endif

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(x)	(sizeof(x) / sizeof((x)[0]))
#endif

#define imagecolumns 82
#define imagerows 62
//define imagecolumns 80
//#define imagerows 60

typedef signed int 	Int32S;
typedef unsigned int	Int32U;
typedef signed short	Int16S;
typedef unsigned short	Int16U;
typedef signed char	Int8S;
typedef unsigned char	Int8U;
typedef unsigned int	Boolean;

typedef int  Device; /* Device ID */
typedef unsigned char BYTE;
typedef BYTE image[imagerows][imagecolumns];
typedef BYTE colimage[imagerows][imagecolumns][3];

typedef short   TypeID;
typedef short   DeviceSemantics;
typedef int MotorHandle;
typedef int ServoHandle;
typedef int PSDHandle;
typedef int QuadHandle;
typedef int BumpHandle;
typedef int IRHandle;
typedef int VWHandle;
typedef int PPWAHandle;
#endif 
