#ifndef __SERIAL_H__
#define __SERIAL_H__

/*!
 * Initialize debug uart
 *
 * @param   uart        pointer to the uart module structure
 * @param   baud        desired baud rate for ommunicating to external device
 */
void init_debug_uart(Int32U baud);

/*!
 * Output a character to the debug uart port
 *
 * @param       ch      character for output
 */
void serial_putc(unsigned char ch);

/*!
 * Receive a character for the debug uart port
 *
 * @return      a character received from the debug uart port; if the fifo
 *              is empty, return 0xff
 */
char serial_getc(void);

/*!
 * Output a string to the debug uart port
 *
 * @param       s  	string for output
 */
void serial_puts(const char *s);
#endif // __SERIAL_H__
