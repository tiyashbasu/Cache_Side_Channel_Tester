#include <includes.h>

//=============================================================================
// STMP Serial Port (UARTx) for Debug
//=============================================================================
struct stmp_serial {            //0x80070000
    volatile Int32U HW_UARTDBGDR;  //0x0
    volatile Int32U HW_UARTDBGRSR; //0x4
    volatile Int32U reserved1[4];
    volatile Int32U HW_UARTDBGFR;  //0x18
    volatile Int32U reserved2;     //0x1c
    volatile Int32U HW_UARTDBGILPR;    //0x20
    volatile Int32U HW_UARTDBGIBRD;    //0x24
    volatile Int32U HW_UARTDBGFBRD;    //0x28
    volatile Int32U HW_UARTDBGLCR; //0x2c
    volatile Int32U HW_UARTDBGCR;  //0x30
    volatile Int32U HW_UARTDBGIFLS;    //0x34
    volatile Int32U HW_UARTDBGIMSC;    //0x38
    volatile Int32U HW_UARTDBGRIS; //0x3c
    volatile Int32U HW_UARTDBGMIS; //0x40
    volatile Int32U HW_UARTDBGICR; //0x44
    volatile Int32U HW_UARTDBGMACR;    //0x48

};

static volatile struct stmp_serial *stmp_debug_uart;

/*!
 * Initialize debug uart
 *
 * @param   uart        pointer to the uart module structure
 * @param   baud        desired baud rate for ommunicating to external device
 */
void init_debug_uart(Int32U baud)
{
    Int32U val;

    stmp_debug_uart = (volatile struct stmp_serial *)UART1_BASE_ADDR;

    /* Configure IOMUX */

    /*
       ;;  setup pinmux for primary:
       ;;
       ;;
       ;;  3:2 BANK1_PIN27 RW 0x3 PWM1 pin function selection:
       ;;     00= pwm1;
       ;;     01= rotaryB;
       ;;     10= uart1_tx;
       ;;     11= GPIO.
       ;;  1:0 BANK1_PIN26 RW 0x3 PWM0 pin function selection:
       ;;     00= pwm0;
       ;;     01= rotaryA;
       ;;     10= uart1_rx;
       ;;     11= GPIO

     */
    writel(0xa, HW_PINCTRL_MUXSEL7_SET);
    writel(0x5, HW_PINCTRL_MUXSEL7_CLR);
    writel(0xf0000, HW_PINCTRL_MUXSEL7_SET);    /*BANK3_PIN25 BANK3_PIN24 to GPIO */

    /* check clocks */
    if ((readl(CLKCTRL_XTAL_ADDR) & 0x80000000))
        writel(0x80000000, CLKCTRL_XTAL_CLR_ADDR);

    /* make sure divider is 1 (24mhz), i.e. easiest to just set it.. */
    val = readl(CLKCTRL_XTAL_ADDR);
    val &= ~0x3;
    val |= 0x1;
    writel(val, CLKCTRL_XTAL_ADDR);

    /* Wait for UART to finish transmitting */
    while (!(stmp_debug_uart->HW_UARTDBGFR & (1 << 7))) ;

    // Now that we have clocks, disable debug UART
    stmp_debug_uart->HW_UARTDBGCR = 0x0;    //Control Reg

    /* Baud rate @115200 baud  */
    stmp_debug_uart->HW_UARTDBGIBRD = 13;
    stmp_debug_uart->HW_UARTDBGFBRD = 1;

    // NOTE: This must happen AFTER setting the baud rate!
    // Set for 8 bits, 1 stop, no parity, enable fifo
    stmp_debug_uart->HW_UARTDBGLCR = (0x3 << 5) | 0x10; // 8-bit word, Enable FIFOs

    // Start it up
    stmp_debug_uart->HW_UARTDBGCR = (0x3 << 8) | 0x1;   // enable Tx, Rx and UART

}

/*!
 * Output a character to the debug uart port
 *
 * @param       ch      character for output
 */
void serial_putc(unsigned char ch)
{
    // Wait for Tx FIFO not full
    while (stmp_debug_uart->HW_UARTDBGFR & (1 << 5)) {  // tx fifo not full
    }

    if (ch == '\n') {          // Replace line feed with '\r'
        stmp_debug_uart->HW_UARTDBGDR = '\r';
        while (stmp_debug_uart->HW_UARTDBGFR & (1 << 5)) {
        }
    }

    stmp_debug_uart->HW_UARTDBGDR = ch;
}

/*!
 * Receive a character for the debug uart port
 *
 * @return      a character received from the debug uart port; if the fifo
 *              is empty, return 0xff
 */
char serial_getc(void)
{
    // If receive fifo is empty, return false
    if (stmp_debug_uart->HW_UARTDBGFR & (1 << 4))
        return 0xFF;

    return (Int8U) (stmp_debug_uart->HW_UARTDBGDR & 0xFF);
}

/*!
 * Output a string to the debug uart port
 *
 * @param       s  	string for output
 */
void serial_puts(const char *s)
{
	while (*s) {
		serial_putc (*s++);
	}
}

