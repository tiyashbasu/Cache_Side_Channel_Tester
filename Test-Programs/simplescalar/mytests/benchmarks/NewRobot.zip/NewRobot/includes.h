/*
*********************************************************************************************************
*                                                uC/OS-II
*                                          The Real-Time Kernel
*
*                              (c) Copyright 1992-2005, Micrium, Weston, FL
*                                           All Rights Reserved
*
*                                           MASTER INCLUDE FILE
*********************************************************************************************************
*/

#ifndef  INCLUDES_H
#define  INCLUDES_H

#define TASK_TO_MEASURE 1

/* Set macro wrapper to disable certain statements */
#if 0
#  define D(x) x
#else
#  define D(x) 
#endif
#if 0
#  define D2(x) x
#else
#  define D2(x) 
#endif
#if 0
#  define D3(x) x
#else
#  define D3(x) 
#endif

/* define memory address to store measured execution time */
#define TASK_BAL_EXEC_TIME 0x40050000
#define TASK_NAV_EXEC_TIME 0x40050010
#define TASK_REMOTE_EXEC_TIME 0x40050020
#define TICK_ISR_EXEC_TIME 0x40050030
extern unsigned int exec_time_addr, exec_time_addr_max;
extern unsigned int time_start, time_end;

/* Basic include files used for all application */
#include  <stdio.h>
#include  <string.h>
#include  <ctype.h>
#include  <stdlib.h>
#include  <stdarg.h>

#include  <ucos_ii.h>

#include  <imx286_regs.h> // iMX286 registers 
#include  <regsdigctl.h>

#include  <bsp.h>         // Board support package
#include  <arm_types.h>   // Redefine data types
#include  <io.h>          // Fundamental IO function (read/write register)
#include  <serial.h>      // Library for UART port

#include  <vsprintf.h>
#include  <console.h>     // Printf support

#include  <math.h>

/* Application specific include files */
/* Include files for RobotApp	      */
#include <vision.h>
#include <kalman.h>
#include <motor.h>
#include <servo.h>
#include <encoder.h>
#include <gyro.h>
#include <inclino.h>
#include <ir_control.h>
#include <timer.h>
#include <camera.h>
#include <hdt_sem.h>

/* Some functions from Papabench are used */
#include <modem.h>
#include <messages.h>

void start_measure_wcet();
void write_wcet();
#define START_MEASURE() start_measure_wcet()
#define END_MEASURE() write_wcet()

#endif                                                                 

